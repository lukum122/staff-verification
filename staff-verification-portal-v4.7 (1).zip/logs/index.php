<?php
require_once __DIR__.'/../config/config.php'; require_once __DIR__.'/../config/database.php'; require_once __DIR__.'/../includes/auth.php'; require_once __DIR__.'/../includes/functions.php'; require_admin();
$rows=$pdo->query("SELECT l.*,s.first_name,s.last_name,s.staff_id AS staff_code,c.name company_name FROM verification_logs l LEFT JOIN staff s ON s.id=l.staff_id LEFT JOIN companies c ON c.id=l.company_id ORDER BY l.id DESC LIMIT 300")->fetchAll();
?>
<?php $page_title='Verification Logs'; include __DIR__.'/../includes/header.php'; ?>
<div class="page-head"><div><h1>Verification Logs</h1><div class="muted">Latest 300 verification attempts.</div></div></div>
<div class="table-wrap"><table class="table"><tr><th>Date</th><th>Staff</th><th>Company</th><th>Result</th><th>IP</th></tr>
<?php foreach($rows as $r): ?><tr><td><?=e($r['verified_at'])?></td><td><?=e(trim(($r['first_name']??'').' '.($r['last_name']??'')))?><div class="small muted"><?=e($r['staff_code']??'')?></div></td><td><?=e($r['company_name']??'Unknown')?></td><td><?=e(strtoupper($r['result']))?></td><td><?=e($r['ip_address']??'—')?></td></tr><?php endforeach;?>
<?php if(!$rows): ?><tr><td colspan="5" class="empty">No verification logs yet.</td></tr><?php endif;?></table></div>
<?php include __DIR__.'/../includes/footer.php'; ?>
