-- SVP V2.8 safe migration
-- Adds per-company ID card settings and per-staff photo crop settings.
-- Existing companies, staff records, photos, signatures and verification tokens are preserved.
ALTER TABLE companies ADD COLUMN id_card_settings JSON NULL AFTER id_card_template_id;
ALTER TABLE staff ADD COLUMN photo_crop JSON NULL AFTER photo;
