<?php
require_once __DIR__.'/config/config.php';
require_once __DIR__.'/config/database.php';
require_once __DIR__.'/includes/auth.php';
require_once __DIR__.'/includes/functions.php';
require_admin();

$companies = (int)$pdo->query("SELECT COUNT(*) FROM companies")->fetchColumn();
$total = (int)$pdo->query("SELECT COUNT(*) FROM staff")->fetchColumn();
$active = (int)$pdo->query("SELECT COUNT(*) FROM staff WHERE status='active'")->fetchColumn();
$logs = (int)$pdo->query("SELECT COUNT(*) FROM verification_logs")->fetchColumn();

$recent = $pdo->query(
    "SELECT l.*, s.first_name, s.last_name, s.staff_id AS staff_code, c.name AS company_name
     FROM verification_logs l
     LEFT JOIN staff s ON s.id=l.staff_id
     LEFT JOIN companies c ON c.id=l.company_id
     ORDER BY l.id DESC LIMIT 10"
)->fetchAll();
?>
<?php $page_title='Dashboard'; include __DIR__.'/includes/header.php'; ?>
<div class="page-head">
  <div><h1>Dashboard</h1><div class="muted">Welcome, <?= e($_SESSION['admin_name'] ?? 'Admin') ?>.</div></div>
  <a class="btn" href="<?= e(base_url('staff/add.php')) ?>">+ Add Staff</a>
</div>
<div class="grid">
  <div class="card"><div class="muted">Companies</div><div class="metric"><?= $companies ?></div></div>
  <div class="card"><div class="muted">Total Staff</div><div class="metric"><?= $total ?></div></div>
  <div class="card"><div class="muted">Active Staff</div><div class="metric"><?= $active ?></div></div>
  <div class="card"><div class="muted">Verifications</div><div class="metric"><?= $logs ?></div></div>
</div>
<div class="card" style="margin-top:20px">
<h3>Recent Verifications</h3>
<?php if (!$recent): ?><div class="empty">No verification activity yet.</div><?php else: ?>
<div class="table-wrap"><table class="table"><tr><th>Staff</th><th>Company</th><th>Result</th><th>Date</th></tr>
<?php foreach ($recent as $r): ?>
<tr>
<td><?= e(trim(($r['first_name']??'').' '.($r['last_name']??''))) ?: 'Unknown' ?><div class="small muted"><?= e($r['staff_code'] ?? '') ?></div></td>
<td><?= e($r['company_name'] ?? 'Unknown') ?></td>
<td><?= status_badge($r['result'] === 'verified' ? 'active' : 'inactive') ?> <span class="small"><?= e(strtoupper($r['result'])) ?></span></td>
<td><?= e($r['verified_at']) ?></td>
</tr>
<?php endforeach; ?>
</table></div><?php endif; ?>
</div>
<?php include __DIR__.'/includes/footer.php'; ?>
