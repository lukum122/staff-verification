-- SVP V2.6 safe migration
-- Adds an optional staff signature image. Existing records and verification tokens are preserved.
ALTER TABLE staff ADD COLUMN signature VARCHAR(255) NULL AFTER photo;
