<?php
declare(strict_types=1);
require_once __DIR__.'/../config/config.php'; require_once __DIR__.'/../config/database.php'; require_once __DIR__.'/../includes/auth.php'; require_once __DIR__.'/../includes/functions.php'; require_once __DIR__.'/../includes/id_card_engine.php'; require_admin();
header('Content-Type: text/html; charset=utf-8');

$companyId = (int)($_POST['company_id'] ?? 0);
$side      = ($_POST['side'] ?? 'front') === 'back' ? 'back' : 'front';
$orientation = safe_card_orientation((string)($_POST['orientation'] ?? 'portrait'));
$layout    = parse_layout($_POST['layout'] ?? '[]');
$bgImage   = trim((string)($_POST['bg_image'] ?? '')) ?: null;

$company = null;
if ($companyId) { $s = $pdo->prepare("SELECT * FROM companies WHERE id=?"); $s->execute([$companyId]); $company = $s->fetch() ?: null; }

$defaults = ['primary'=>'#155d3b','secondary'=>'#76b82a','text'=>'#172033','muted'=>'#667085','title'=>'STAFF ID CARD','tagline'=>'','show_tagline'=>true,'bottom_text'=>'','show_bottom_text'=>true,'show_website'=>false,'photo_shape'=>'rounded'];
$settings = $defaults;
if ($company && !empty($company['id_card_settings'])) { $x = json_decode((string)$company['id_card_settings'], true); if (is_array($x)) $settings = array_merge($settings, $x); }

$sample = null;
if ($companyId) { $s = $pdo->prepare("SELECT * FROM staff WHERE company_id=? ORDER BY id DESC LIMIT 1"); $s->execute([$companyId]); $sample = $s->fetch() ?: null; }

$values = [
    'company_name' => $company['name'] ?? 'Company Name', 'tagline' => $settings['tagline'], 'title' => $settings['title'], 'staff_id_label'=>'Staff ID', 'important_title'=>'IMPORTANT', 'contact_title'=>'COMPANY CONTACT',
    'name' => $sample ? trim(($sample['first_name'] ?? '').' '.($sample['last_name'] ?? '')) : 'Staff Name',
    'position' => $sample['position'] ?? 'Position', 'staff_id' => $sample['staff_id'] ?? 'STAFF-001',
    'qr_label' => 'Scan to Verify', 'bottom_text' => $settings['bottom_text'],
    'logo_url' => !empty($company['logo']) ? base_url($company['logo']) : null,
    'photo_url' => $sample && !empty($sample['photo']) ? base_url($sample['photo']) : null,
    'signature_url' => $sample && !empty($sample['signature']) ? base_url($sample['signature']) : null,
    'important' => "This card remains the property of the company.\nIf found, please return to the address below.",
    'contact' => trim(($company['address'] ?? '')."\n".($company['phone'] ?? '')."\n".($company['email'] ?? '')),
    'signature_label' => 'STAFF SIGNATURE',
    'dates' => 'Issued: '.date('M Y').'   Expiry: '.($sample['expiry_date'] ?? 'N/A'),
    'back_bottom' => $settings['bottom_text'],
    'verification_url' => $sample ? base_url('v/'.$sample['verification_token']) : base_url('v/SAMPLE01'),
];

echo render_card_face($side, $orientation, 'custom', $layout, $values, $settings, $bgImage);
