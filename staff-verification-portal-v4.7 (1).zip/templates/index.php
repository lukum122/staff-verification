<?php
declare(strict_types=1);
require_once __DIR__.'/../config/config.php'; require_once __DIR__.'/../config/database.php'; require_once __DIR__.'/../includes/auth.php'; require_once __DIR__.'/../includes/functions.php'; require_once __DIR__.'/../includes/id_card_engine.php'; require_admin();
seed_builtin_templates($pdo);
$companyId=(int)($_GET['company_id']??$_POST['company_id']??0);
$companies=$pdo->query("SELECT * FROM companies WHERE status='active' ORDER BY name")->fetchAll();
if(!$companyId && $companies) $companyId=(int)$companies[0]['id'];
$company=null; foreach($companies as $c){if((int)$c['id']===$companyId){$company=$c;break;}}
if(!$company){http_response_code(404);exit('Company not found.');}
$templates=$pdo->query("SELECT * FROM id_card_templates WHERE is_active=1 AND (is_builtin=1 OR (is_builtin=0 AND front_image IS NULL AND back_image IS NULL)) ORDER BY is_builtin DESC,name")->fetchAll();
$defaults=['primary'=>'#155d3b','secondary'=>'#76b82a','text'=>'#172033','muted'=>'#667085','title'=>'STAFF ID CARD','tagline'=>'','show_tagline'=>true,'bottom_text'=>'','show_bottom_text'=>true,'show_website'=>false,'photo_shape'=>'auto'];
$settings=$defaults; if(!empty($company['id_card_settings'])){ $x=json_decode((string)$company['id_card_settings'],true); if(is_array($x))$settings=array_merge($settings,$x); }
$msg='';$err='';
if($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action']??'')==='save_branding'){
 verify_csrf($_POST['csrf_token']??null);
 try{
  foreach(['primary','secondary','text','muted'] as $k){$v=trim((string)($_POST[$k]??'')); if(!preg_match('/^#[0-9a-fA-F]{6}$/',$v)) throw new RuntimeException('Invalid colour.'); $settings[$k]=$v;}
  foreach(['title','tagline','bottom_text'] as $k)$settings[$k]=trim((string)($_POST[$k]??''));
  $settings['show_tagline']=isset($_POST['show_tagline']); $settings['show_bottom_text']=isset($_POST['show_bottom_text']); $settings['show_website']=isset($_POST['show_website']);
  $settings['photo_shape']=in_array($_POST['photo_shape']??'auto',['auto','rectangle','rounded','circle'],true)?$_POST['photo_shape']:'auto';
  $templateId=(int)($_POST['template_id']??0); if($templateId && !get_template($pdo,$templateId))$templateId=0;
  $pdo->prepare("UPDATE companies SET id_card_template_id=?, id_card_settings=? WHERE id=?")->execute([$templateId?:null,json_encode($settings,JSON_UNESCAPED_SLASHES),$companyId]);
  $company['id_card_template_id']=$templateId; $msg='ID card template and branding saved.';
 }catch(Throwable $e){$err=$e->getMessage();}
}
$selected=(int)($company['id_card_template_id']??0); if(!$selected && $templates)$selected=(int)$templates[0]['id'];
$sampleStmt=$pdo->prepare("SELECT * FROM staff WHERE company_id=? ORDER BY id DESC LIMIT 1");$sampleStmt->execute([$companyId]);$sample=$sampleStmt->fetch()?:null;

// Sample values used to render every thumbnail — same shape of data the real generator uses.
$sampleValues=[
    'company_name'=>$company['name'], 'tagline'=>$settings['tagline'], 'title'=>$settings['title'],
    'name'=>$sample?trim(($sample['first_name']??'').' '.($sample['last_name']??'')):'Staff Name',
    'position'=>$sample['position']??'Position', 'staff_id'=>$sample['staff_id']??'STAFF-001',
    'qr_label'=>'Scan to Verify', 'bottom_text'=>$settings['bottom_text'],
    'logo_url'=>!empty($company['logo'])?base_url($company['logo']):null,
    'verification_url'=>$sample?base_url('v/'.$sample['verification_token']):base_url('v/SAMPLE01'),
];

// Canonical on-screen size every thumbnail is rendered at full scale, then shrunk with
// transform:scale() — this is what guarantees the thumbnail is pixel-identical to the
// real card, not a separate re-drawing of it.
const THUMB_BASE_LONG = 460.0;
function thumb_dims(string $orientation): array {
    $short = THUMB_BASE_LONG * CARD_SHORT_MM / CARD_LONG_MM;
    return $orientation === 'portrait' ? [$short, THUMB_BASE_LONG] : [THUMB_BASE_LONG, $short];
}
$page_title='ID Card Templates'; include __DIR__.'/../includes/header.php';
?>
<div class="page-head"><div><h1>ID Card Templates</h1><div class="muted"><?=e($company['name'])?> · choose a finished structured design and customize its elements.</div></div><a class="btn secondary" href="<?=e(base_url('companies/view.php?id='.$companyId))?>">Back to Company</a></div>
<?php if($msg):?><div class="alert" style="background:#ecfdf3;border-color:#abefc6;color:#067647"><?=e($msg)?></div><?php endif;?><?php if($err):?><div class="alert"><?=e($err)?></div><?php endif;?>
<form method="post"><input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>"><input type="hidden" name="company_id" value="<?=$companyId?>"><input type="hidden" name="action" value="save_branding">
<div class="library-head"><div><h2>Finished Templates</h2><p class="muted">Structured templates with editable design objects. No flattened artwork is used.</p></div></div>
<div class="template-grid">
<?php foreach($templates as $t):
  $isSelected=$selected===(int)$t['id'];
  $layout=template_layout($t)['front'];
  $bgImage=null;
  [$w,$h]=thumb_dims($t['orientation']);
  $boxTarget=214.0; $scale=$boxTarget/max($w,$h);
  $scaledW=$w*$scale; $scaledH=$h*$scale;
  $face=render_card_face('front',$t['orientation'],(string)($t['design_key']??'custom'),$layout,$sampleValues,$settings,$bgImage);
?>
<label class="template-card <?=$isSelected?'selected':''?>"><input type="radio" name="template_id" value="<?=$t['id']?>" <?=$isSelected?'checked':''?> onchange="selectCard(this)">
<div class="thumb-wrap"><div class="thumb-scaler" style="width:<?=$scaledW?>px;height:<?=$scaledH?>px"><div style="width:<?=$w?>px;height:<?=$h?>px;transform:scale(<?=$scale?>);transform-origin:top left"><?=$face?></div></div></div>
<div class="template-info"><strong><?=e($t['name'])?></strong><span><?=e(ucfirst($t['orientation']))?> · <?=e($t['category'])?></span></div>
<div class="template-actions"><?php if((int)$t['is_builtin']===1):?><a class="small-btn" href="<?=e(base_url('templates/custom_editor.php?company_id='.$companyId.'&source='.$t['id']))?>">Customize</a><?php else:?><a class="small-btn" href="<?=e(base_url('templates/custom_editor.php?company_id='.$companyId.'&template_id='.$t['id']))?>">Edit</a><?php endif;?></div></label>
<?php endforeach;?></div>
<div class="settings-grid card"><div><h3>Company Branding</h3><div class="muted small">These values change the content without changing the template structure.</div></div><div class="settings-fields"><label>Primary <input type="color" name="primary" value="<?=e($settings['primary'])?>"></label><label>Secondary <input type="color" name="secondary" value="<?=e($settings['secondary'])?>"></label><label>Text <input type="color" name="text" value="<?=e($settings['text'])?>"></label><label>Muted <input type="color" name="muted" value="<?=e($settings['muted'])?>"></label><label>Card title <input name="title" value="<?=e($settings['title'])?>"></label><label>Tagline <input name="tagline" value="<?=e($settings['tagline'])?>"></label><label>Bottom slogan/text <input name="bottom_text" value="<?=e($settings['bottom_text'])?>"></label><label>Photo shape <select name="photo_shape"><option value="auto" <?=$settings['photo_shape']==='auto'?'selected':''?>>Auto (each template's own shape)</option><option value="rectangle" <?=$settings['photo_shape']==='rectangle'?'selected':''?>>Rectangle</option><option value="rounded" <?=$settings['photo_shape']==='rounded'?'selected':''?>>Rounded rectangle</option><option value="circle" <?=$settings['photo_shape']==='circle'?'selected':''?>>Circle</option></select></label><label class="check"><input type="checkbox" name="show_tagline" <?=$settings['show_tagline']?'checked':''?>> Show tagline</label><label class="check"><input type="checkbox" name="show_bottom_text" <?=$settings['show_bottom_text']?'checked':''?>> Show bottom slogan/text</label><label class="check"><input type="checkbox" name="show_website" <?=$settings['show_website']?'checked':''?>> Show website on back only when company website exists</label></div><button class="btn" type="submit">Save Selection & Branding</button></div>
</form>
<style><?=card_engine_css()?>
.library-head{display:flex;justify-content:space-between;gap:15px;align-items:center;margin:20px 0 14px}.template-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:16px}.template-card{position:relative;background:#fff;border:2px solid #e4e7ec;border-radius:16px;padding:12px;cursor:pointer;transition:.15s}.template-card.selected{border-color:#155d3b;box-shadow:0 0 0 3px #155d3b18}.template-card input{position:absolute;opacity:0}.thumb-wrap{height:230px;display:grid;place-items:center;background:#f2f4f7;border-radius:12px;padding:10px;overflow:hidden}.thumb-scaler{overflow:hidden;box-shadow:0 10px 24px #10182822;border-radius:6px}
.template-info{padding:10px 2px 4px}.template-info strong{display:block}.template-info span{font-size:12px;color:#667085}.template-actions{margin-top:6px}.small-btn{display:inline-block;padding:6px 9px;border:1px solid #d0d5dd;border-radius:8px;font-size:12px;color:#344054;text-decoration:none;background:#fff}.settings-grid{margin-top:22px;padding:18px;display:grid;gap:16px}.settings-fields{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}.settings-fields label{display:grid;gap:6px;font-size:13px;font-weight:600}.settings-fields input[type=text],.settings-fields input:not([type]),.settings-fields select{width:100%}.settings-fields input[type=color]{width:100%;height:40px;padding:2px}.settings-fields .check{display:flex;align-items:center;gap:7px;font-weight:500}.settings-fields .check input{width:auto}.small{font-size:12px}@media(max-width:800px){.library-head{flex-direction:column;align-items:flex-start}.settings-fields{grid-template-columns:1fr 1fr}}@media(max-width:520px){.settings-fields{grid-template-columns:1fr}}
</style>
<script>function selectCard(el){document.querySelectorAll('.template-card').forEach(c=>c.classList.remove('selected'));el.closest('.template-card').classList.add('selected')}</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
<script>document.querySelectorAll('.qr-box').forEach(function(el){if(window.QRCode)new QRCode(el,{text:el.dataset.qr||'',width:256,height:256,correctLevel:QRCode.CorrectLevel.M});});</script>
<?php include __DIR__.'/../includes/footer.php'; ?>
