-- SVP V2.3 safe migration
-- Adds optional middle name without changing existing staff records or verification tokens.
ALTER TABLE staff ADD COLUMN middle_name VARCHAR(100) NULL AFTER first_name;
