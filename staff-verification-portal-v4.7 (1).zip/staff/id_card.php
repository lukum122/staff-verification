<?php
declare(strict_types=1);
require_once __DIR__.'/../config/config.php'; require_once __DIR__.'/../config/database.php'; require_once __DIR__.'/../includes/auth.php'; require_once __DIR__.'/../includes/functions.php'; require_once __DIR__.'/../includes/id_card_engine.php'; require_admin();

$id = (int)($_GET['id'] ?? 0);
$side = $_GET['side'] ?? 'both'; if (!in_array($side, ['front','back','both'], true)) $side = 'both';

$q = $pdo->prepare("SELECT s.*, c.name company_name, c.logo company_logo, c.address company_address, c.phone company_phone, c.email company_email, c.website company_website, c.id_card_template_id, c.id_card_settings FROM staff s JOIN companies c ON c.id = s.company_id WHERE s.id=?");
$q->execute([$id]); $s = $q->fetch();
if (!$s) { http_response_code(404); exit('Staff record not found.'); }

seed_builtin_templates($pdo);
$template = !empty($s['id_card_template_id']) ? get_template($pdo, (int)$s['id_card_template_id']) : null;
if (!$template) $template = $pdo->query("SELECT * FROM id_card_templates WHERE is_builtin=1 AND is_active=1 ORDER BY id LIMIT 1")->fetch() ?: null;
if (!$template) { http_response_code(500); exit('No ID card template available.'); }

$settings = ['primary'=>'#155d3b','secondary'=>'#76b82a','text'=>'#172033','muted'=>'#667085','title'=>'STAFF ID CARD','tagline'=>'','show_tagline'=>true,'bottom_text'=>'','show_bottom_text'=>true,'show_website'=>false,'photo_shape'=>'rounded'];
$d = json_decode((string)($s['id_card_settings'] ?? ''), true); if (is_array($d)) $settings = array_merge($settings, $d);

$orientation = safe_card_orientation((string)$template['orientation']);
$layouts = template_layout($template);
$front = $layouts['front']; $back = $layouts['back'];

$fullName = trim(($s['first_name'] ?? '').' '.($s['middle_name'] ?? '').' '.($s['last_name'] ?? ''));
$verificationUrl = base_url('v/'.$s['verification_token']);

$crop = json_decode((string)($s['photo_crop'] ?? ''), true); if (!is_array($crop)) $crop = [];
$photoShapeOverride = in_array(($crop['shape'] ?? ''), ['rectangle','rounded','circle'], true) ? $crop['shape'] : null;
$zoom = max(1, min(3, (float)($crop['zoom'] ?? 1)));
$cx = max(-50, min(50, (float)($crop['x'] ?? 0)));
$cy = max(-50, min(50, (float)($crop['y'] ?? 0)));
$issued = $s['date_employed'] ? date('d M Y', strtotime($s['date_employed'])) : date('d M Y');
$expiry = $s['expiry_date'] ? date('d M Y', strtotime($s['expiry_date'])) : '';

$values = [
    'company_name' => $s['company_name'], 'tagline' => $settings['tagline'], 'title' => $settings['title'], 'staff_id_label' => 'Staff ID', 'important_title' => 'IMPORTANT', 'contact_title' => 'COMPANY CONTACT',
    'name' => $fullName, 'position' => $s['position'], 'staff_id' => $s['staff_id'], 'qr_label' => 'Scan to Verify',
    'important' => 'This card remains the property of '.$s['company_name'].".\nIt must be returned when employment ends.\nIf found, please contact the company.",
    'contact' => trim(($s['company_address'] ?? '')."\n".($s['company_phone'] ?? '')."\n".($s['company_email'] ?? '').($settings['show_website'] && trim((string)$s['company_website']) !== '' ? "\n".$s['company_website'] : '')),
    'dates' => 'Issue Date: '.$issued.($expiry ? '   |   Expiry Date: '.$expiry : ''),
    'bottom_text' => $settings['bottom_text'], 'back_bottom' => $settings['bottom_text'], 'signature_label' => 'STAFF SIGNATURE',
    'logo_url' => $s['company_logo'] ? base_url($s['company_logo']) : null,
    'photo_url' => $s['photo'] ? base_url($s['photo']) : null,
    'signature_url' => $s['signature'] ? base_url($s['signature']) : null,
    'photo_zoom' => $zoom, 'photo_cx' => $cx, 'photo_cy' => $cy, 'photo_shape_override' => $photoShapeOverride,
    'verification_url' => $verificationUrl,
];

$bgFront = $template['front_image'] ? base_url($template['front_image']) : null;
$bgBack  = $template['back_image']  ? base_url($template['back_image'])  : null;
$designKey = (string)($template['design_key'] ?? 'custom');

$page_title = 'ID Card · '.$fullName; include __DIR__.'/../includes/header.php';
?>
<div class="idgen-page"><div class="page-head"><div><h1>Staff ID Card</h1><div class="muted"><?=e($fullName)?> · <?=e($s['company_name'])?> · <?=e($template['name'])?> · <?=e(ucfirst($orientation))?></div></div><a class="btn secondary" href="<?=e(base_url('staff/view.php?id='.$id))?>">Back to Staff</a></div>
<div class="idgen-toolbar"><button class="btn" type="button" onclick="downloadCard('front')">Download Front</button><button class="btn secondary" type="button" onclick="downloadCard('back')">Download Back</button><button class="btn secondary" type="button" onclick="downloadPDF()">Download Both (PDF)</button><button class="btn secondary" type="button" onclick="window.print()">Print</button><a class="btn secondary" href="<?=e(base_url('templates/index.php?company_id='.$s['company_id']))?>">Change Template</a></div>
<div class="idgen-note">CR80 standard: 85.60 × 53.98 mm. Downloads contain only the card artwork. Front carries the QR verification code; back does not.</div>
<div class="idgen-stage">
<?php if ($side !== 'back'): ?><div class="card-column"><div class="idgen-label">FRONT</div><div id="cardFront"><?=render_card_face('front',$orientation,$designKey,$front,$values,$settings,$bgFront)?></div></div><?php endif; ?>
<?php if ($side !== 'front'): ?><div class="card-column"><div class="idgen-label">BACK</div><div id="cardBack"><?=render_card_face('back',$orientation,$designKey,$back,$values,$settings,$bgBack)?></div></div><?php endif; ?>
</div></div>
<style><?=card_engine_css()?>
.idgen-toolbar{display:flex;flex-wrap:wrap;gap:8px;margin:16px 0}.idgen-note{background:#f8fafc;border:1px solid #e4e7ec;border-radius:10px;padding:10px 12px;font-size:12px;color:#667085}.idgen-stage{display:flex;gap:32px;align-items:flex-start;justify-content:center;flex-wrap:wrap;padding:28px;background:#f2f4f7;border-radius:16px;margin-top:16px}.card-column{display:flex;flex-direction:column;align-items:center;gap:8px}.idgen-label{font-size:12px;font-weight:800;letter-spacing:.08em;color:#475467}
.idgen-stage .card-stage{width:53.98mm;box-shadow:0 18px 45px #10182825}.idgen-stage .card-stage.landscape{width:85.6mm}
@media print{body{background:#fff!important}.no-print,header,footer,.idgen-toolbar,.idgen-note,.page-head,.idgen-label{display:none!important}.idgen-stage{padding:0!important;margin:0!important;background:#fff!important;display:flex!important;gap:4mm!important;justify-content:flex-start!important}.card-stage{box-shadow:none!important}.idgen-page{padding:0!important;margin:0!important}}
</style>
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script><script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script><script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script>
(function(){document.querySelectorAll('.qr-box').forEach(function(el){if(window.QRCode)new QRCode(el,{text:el.dataset.qr||'',width:256,height:256,correctLevel:QRCode.CorrectLevel.M});});})();
const ORI=<?=json_encode($orientation)?>;const W=ORI==='portrait'?53.98:85.6,H=ORI==='portrait'?85.6:53.98;
async function ready(){await new Promise(r=>setTimeout(r,500));}
async function canvasFor(id){await ready();const el=document.getElementById(id)?.querySelector('.card-stage');if(!el)throw new Error('Card side not found');return html2canvas(el,{scale:4,useCORS:true,backgroundColor:'#ffffff',logging:false});}
function saveCanvas(c,name){const a=document.createElement('a');a.download=name;a.href=c.toDataURL('image/png');a.click()}
async function downloadCard(side){try{const c=await canvasFor(side==='front'?'cardFront':'cardBack');saveCanvas(c,<?=json_encode(preg_replace('/[^A-Za-z0-9_-]+/','-',strtolower($fullName)))?>+'-'+side+'.png')}catch(e){alert('Download failed. Please wait for the card to finish rendering and try again.')}}
async function downloadPDF(){try{const js=window.jspdf;if(!js)throw new Error('PDF library unavailable');const pdf=new js.jsPDF({orientation:ORI,unit:'mm',format:[W,H]});let first=true;for(const side of ['front','back']){const id=side==='front'?'cardFront':'cardBack';if(!document.getElementById(id))continue;const c=await canvasFor(side);if(!first)pdf.addPage([W,H],ORI);pdf.addImage(c.toDataURL('image/png'),'PNG',0,0,W,H);first=false;}pdf.save(<?=json_encode(preg_replace('/[^A-Za-z0-9_-]+/','-',strtolower($fullName)))?>+'-id-card.pdf')}catch(e){alert('PDF download failed. Please ensure the page has finished loading and try again.')}}
</script>
<?php include __DIR__.'/../includes/footer.php'; ?>
