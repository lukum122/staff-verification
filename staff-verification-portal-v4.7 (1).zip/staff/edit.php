<?php
require_once __DIR__.'/../config/config.php'; require_once __DIR__.'/../config/database.php'; require_once __DIR__.'/../includes/auth.php'; require_once __DIR__.'/../includes/functions.php'; require_admin();

$id=(int)($_GET['id']??0);
$stmt=$pdo->prepare("SELECT s.*,c.name company_name FROM staff s INNER JOIN companies c ON c.id=s.company_id WHERE s.id=?");$stmt->execute([$id]);$s=$stmt->fetch();
if(!$s){http_response_code(404);exit('Staff record not found.');}

$companies=$pdo->query("SELECT id,name FROM companies ORDER BY name")->fetchAll();
$error='';

if($_SERVER['REQUEST_METHOD']==='POST'){
 verify_csrf($_POST['csrf_token']??null);
 try{
  $companyId=(int)($_POST['company_id']??0); $staffId=clean_staff_id($_POST['staff_id']??'');
  $first=trim($_POST['first_name']??''); $middle=trim($_POST['middle_name']??''); $last=trim($_POST['last_name']??''); $position=trim($_POST['position']??'');
  if(!$companyId||!$staffId||!$first||!$last||!$position) throw new RuntimeException('Company, Staff ID, first name, last name and position are required.');

  $dup=$pdo->prepare("SELECT id FROM staff WHERE company_id=? AND staff_id=? AND id<>? LIMIT 1");$dup->execute([$companyId,$staffId,$id]);
  if($dup->fetch()) throw new RuntimeException('That Staff ID already exists under this company.');

  // Preserve the existing photo unless a new photo is successfully uploaded.
  $photo=$s['photo'];
  $signature=$s['signature'] ?? null;
  $photoCrop=$s['photo_crop'] ?? null;
  if(isset($_FILES['photo']) && ($_FILES['photo']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE){
    $newPhoto=save_uploaded_image($_FILES['photo'], 'staff');
    if($newPhoto){
      delete_uploaded_file($photo);
      $photo=$newPhoto;
    }
  }

  if(isset($_FILES['signature']) && ($_FILES['signature']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE){
    $newSignature=save_uploaded_signature($_FILES['signature']);
    if($newSignature){
      delete_uploaded_file($signature);
      $signature=$newSignature;
    }
  }

  $stmt=$pdo->prepare("UPDATE staff SET company_id=?,staff_id=?,first_name=?,middle_name=?,last_name=?,photo=?,photo_crop=?,signature=?,position=?,department=?,phone=?,email=?,date_employed=?,expiry_date=?,status=? WHERE id=?");
  $cropJson=trim((string)($_POST['photo_crop']??''));
  if($cropJson!==''){
    $decodedCrop=json_decode($cropJson,true);
    if(!is_array($decodedCrop)) throw new RuntimeException('Invalid photo crop data. Please refresh the page and try again.');
    $photoCrop=json_encode($decodedCrop,JSON_UNESCAPED_SLASHES);
  }
  $stmt->execute([$companyId,$staffId,$first,$middle,$last,$photo,$photoCrop,$signature,$position,trim($_POST['department']??''),trim($_POST['phone']??''),trim($_POST['email']??''),$_POST['date_employed']?:null,$_POST['expiry_date']?:null,$_POST['status']??'active',$id]);
  redirect('staff/view.php?id='.$id);
 }catch(Throwable $e){$error=$e->getMessage();}
}
?>
<?php $page_title='Edit Staff'; include __DIR__.'/../includes/header.php'; ?>
<div class="form-card"><h2>Edit Staff</h2><?php if($error):?><div class="alert"><?=e($error)?></div><?php endif;?>
<form method="post" enctype="multipart/form-data"><input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>">
<div class="field"><label>Company *</label><select name="company_id" required><?php foreach($companies as $c):?><option value="<?=$c['id']?>" <?=$s['company_id']==$c['id']?'selected':''?>><?=e($c['name'])?></option><?php endforeach;?></select></div>
<div class="two"><div class="field"><label>First Name *</label><input name="first_name" value="<?=e($s['first_name'])?>" required></div><div class="field"><label>Middle Name</label><input name="middle_name" value="<?=e($s['middle_name'] ?? '')?>"></div></div>
<div class="field"><label>Last Name *</label><input name="last_name" value="<?=e($s['last_name'])?>" required></div>
<div class="field"><label>Staff ID *</label><input name="staff_id" value="<?=e($s['staff_id'])?>" required></div>
<div class="field"><label>Position *</label><input name="position" value="<?=e($s['position'])?>" required></div>
<div class="field"><label>Department</label><input name="department" value="<?=e($s['department'])?>"></div>
<div class="field"><label>Staff Photo</label><?php if(!empty($s['photo'])): ?><div style="display:flex;align-items:center;gap:14px;margin:8px 0 10px"><img src="<?=e(base_url($s['photo']))?>" alt="Current staff photo" style="width:90px;height:90px;object-fit:cover;border-radius:12px;border:1px solid #d8deea"><span class="small muted">Current photo will be kept unless you choose a new one.</span></div><?php else: ?><div class="small muted" style="margin-bottom:8px">No photo uploaded yet.</div><?php endif; ?><input type="file" id="photoInput" name="photo" accept="image/jpeg,image/png,image/webp"><input type="hidden" id="photoCrop" name="photo_crop" value="<?=e($s['photo_crop'] ?? '')?>"><div class="small muted">Optional · JPG, PNG or WEBP · max 2MB. After selecting a photo, adjust zoom and position below so the head is not cut off.</div>
<div id="photoEditor" class="photo-editor" style="display:<?=!empty($s['photo'])?'grid':'none'?>">
  <div class="photo-editor-preview"><img id="photoPreview" src="<?=!empty($s['photo'])?e(base_url($s['photo'])):''?>" alt="Photo crop preview"><div class="crop-guide"></div></div>
  <div class="photo-editor-controls">
    <label>Zoom <input id="photoZoom" type="range" min="1" max="2.5" step="0.01" value="1"></label>
    <label>Horizontal <input id="photoX" type="range" min="-30" max="30" step="1" value="0"></label>
    <label>Vertical <input id="photoY" type="range" min="-30" max="30" step="1" value="0"></label><label>Photo Shape <select id="photoShape"><option value="rectangle">Rectangle</option><option value="rounded">Rounded Rectangle</option><option value="circle">Circle</option></select></label>
    <button class="btn secondary" type="button" id="resetCrop">Reset Crop</button>
  </div>
</div></div>
<div class="field"><label>Staff Signature <span class="muted">(Optional)</span></label><?php if(!empty($s['signature'])): ?><div style="display:flex;align-items:center;gap:14px;margin:8px 0 10px"><div style="width:180px;height:60px;border:1px solid #d8deea;border-radius:10px;background:repeating-conic-gradient(#f5f5f5 0 25%,#fff 0 50%) 50%/16px 16px;display:flex;align-items:center;justify-content:center;padding:6px"><img src="<?=e(base_url($s['signature']))?>" alt="Current staff signature" style="max-width:100%;max-height:100%;object-fit:contain"></div><span class="small muted">Current signature will be kept unless you choose a new one.</span></div><?php else: ?><div class="small muted" style="margin-bottom:8px">No signature uploaded yet.</div><?php endif; ?><input type="file" name="signature" accept="image/jpeg,image/png,image/webp"><div class="small muted">Optional · plain/light backgrounds are automatically removed and the signature is saved with transparency · max 2MB</div></div>
<div class="two"><div class="field"><label>Phone</label><input name="phone" value="<?=e($s['phone'])?>"></div><div class="field"><label>Email</label><input type="email" name="email" value="<?=e($s['email'])?>"></div></div>
<div class="two"><div class="field"><label>Date Employed</label><input type="date" name="date_employed" value="<?=e($s['date_employed'])?>"></div><div class="field"><label>Expiry Date</label><input type="date" name="expiry_date" value="<?=e($s['expiry_date'])?>"></div></div>
<div class="field"><label>Status</label><select name="status"><option value="active" <?=$s['status']==='active'?'selected':''?>>Active</option><option value="inactive" <?=$s['status']==='inactive'?'selected':''?>>Inactive</option></select></div>
<button class="btn full">Save Changes</button></form></div>
<script>
(function(){
 const input=document.getElementById('photoInput'), editor=document.getElementById('photoEditor'), img=document.getElementById('photoPreview');
 const zoom=document.getElementById('photoZoom'), x=document.getElementById('photoX'), y=document.getElementById('photoY'), hidden=document.getElementById('photoCrop');
 if(!input) return;
 let saved={}; try{saved=JSON.parse(hidden.value||'{}')}catch(e){}
 if(saved.zoom) zoom.value=saved.zoom; if(saved.x!==undefined)x.value=saved.x; if(saved.y!==undefined)y.value=saved.y; if(saved.shape) document.getElementById('photoShape').value=saved.shape;
 function apply(){ img.style.transform=`translate(${x.value}%,${y.value}%) scale(${zoom.value})`; hidden.value=JSON.stringify({zoom:parseFloat(zoom.value),x:parseFloat(x.value),y:parseFloat(y.value),shape:document.getElementById('photoShape').value}); }
 [zoom,x,y].forEach(el=>el.addEventListener('input',apply)); document.getElementById('photoShape').addEventListener('change',apply);
 input.addEventListener('change',()=>{const f=input.files&&input.files[0];if(!f)return; const r=new FileReader();r.onload=()=>{img.src=r.result;editor.style.display='grid';apply()};r.readAsDataURL(f)});
 document.getElementById('resetCrop').addEventListener('click',()=>{zoom.value=1;x.value=0;y.value=0;document.getElementById('photoShape').value='rounded';apply()});
 if(input.files&&input.files[0]){editor.style.display='grid';} else if(img.src){editor.style.display='grid'; apply();}
})();
</script>
<style>.photo-editor{grid-template-columns:220px 1fr;gap:14px;margin-top:12px;padding:12px;border:1px solid #dfe4ed;border-radius:12px;background:#f8fafc}.photo-editor-preview{position:relative;width:220px;height:180px;background:#eef2f6;border-radius:10px;overflow:hidden;display:flex;align-items:center;justify-content:center}.photo-editor-preview img{width:100%;height:100%;object-fit:contain;transform-origin:center}.crop-guide{position:absolute;inset:16px 30px;border:2px dashed rgba(7,3,41,.65);border-radius:8px;pointer-events:none}.photo-editor-controls{display:flex;flex-direction:column;gap:12px;justify-content:center}.photo-editor-controls label{font-size:12px;font-weight:700}.photo-editor-controls input[type=range]{width:100%}@media(max-width:600px){.photo-editor{grid-template-columns:1fr}.photo-editor-preview{width:100%;height:220px}}</style>
<?php include __DIR__.'/../includes/footer.php'; ?>
