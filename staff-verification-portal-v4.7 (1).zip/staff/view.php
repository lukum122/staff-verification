<?php
require_once __DIR__.'/../config/config.php'; require_once __DIR__.'/../config/database.php'; require_once __DIR__.'/../includes/auth.php'; require_once __DIR__.'/../includes/functions.php'; require_admin();

$id=(int)($_GET['id']??0);
$stmt=$pdo->prepare("SELECT s.*,c.name company_name,c.status company_status FROM staff s INNER JOIN companies c ON c.id=s.company_id WHERE s.id=?");
$stmt->execute([$id]);$s=$stmt->fetch();
if(!$s){http_response_code(404);exit('Staff record not found.');}

if($_SERVER['REQUEST_METHOD']==='POST'){
 verify_csrf($_POST['csrf_token']??null);
 $action=$_POST['action']??'';
 if($action==='toggle'){
   $new=$s['status']==='active'?'inactive':'active';
   $pdo->prepare("UPDATE staff SET status=? WHERE id=?")->execute([$new,$id]);
   redirect('staff/view.php?id='.$id);
 }
}
$verificationUrl=base_url('v/'.$s['verification_token']);
$currentlyActive=staff_is_currently_active($s) && $s['company_status']==='active';
?>
<?php $page_title=trim($s['first_name'].' '.($s['middle_name'] ?? '').' '.$s['last_name']); include __DIR__.'/../includes/header.php'; ?>
<div class="page-head"><div><h1><?=e(trim($s['first_name'].' '.($s['middle_name'] ?? '').' '.$s['last_name']))?></h1><div class="muted"><?=e($s['company_name'])?> · <?=e($s['staff_id'])?></div></div><a class="btn secondary" href="<?=e(base_url('staff/index.php'))?>">Back to Staff</a></div>
<div class="profile-layout">
<section class="card profile-card">
  <?php if($s['photo']): ?><img class="profile-photo" src="<?=e(base_url($s['photo']))?>" alt="<?=e(trim($s['first_name'].' '.($s['middle_name'] ?? '').' '.$s['last_name']))?>"><?php else: ?><div class="profile-placeholder">SVP</div><?php endif; ?>
  <h2><?=e(trim($s['first_name'].' '.($s['middle_name'] ?? '').' '.$s['last_name']))?></h2>
  <div><?=e($s['position'])?></div>
  <div class="spacer"><?=status_badge($s['status'])?></div>
  <form method="post"><input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="toggle"><button class="btn secondary" type="submit"><?= $s['status']==='active'?'Deactivate Staff':'Activate Staff' ?></button></form>
</section>
<section class="card">
  <h3>Staff Details</h3>
  <div class="details">
    <div><strong>Company</strong><span><?=e($s['company_name'])?></span></div>
    <div><strong>Staff ID</strong><span><?=e($s['staff_id'])?></span></div>
    <div><strong>Position</strong><span><?=e($s['position'])?></span></div>
    <div><strong>Department</strong><span><?=e($s['department'] ?: '—')?></span></div>
    <div><strong>Date Employed</strong><span><?=e($s['date_employed'] ?: '—')?></span></div>
    <div><strong>Expiry Date</strong><span><?=e($s['expiry_date'] ?: '—')?></span></div>
  </div>
  <hr>
  <h3>Verification</h3>
  <div class="code-box"><strong>Verification ID</strong><code><?=e($s['verification_token'])?></code></div>
  <div class="code-box"><strong>Verification URL</strong><input readonly value="<?=e($verificationUrl)?>" onclick="this.select()"></div>
  <div class="qr-wrap"><div id="qrcode"></div><div class="small muted">This QR contains only the permanent verification URL.</div></div>
  <div class="actions">
    <button class="btn" id="downloadQr" type="button">Download QR</button>
    <a class="btn secondary" target="_blank" rel="noopener" href="<?=e($verificationUrl)?>">View Verification</a>
    <a class="btn secondary" href="<?=e(base_url('staff/edit.php?id='.$id))?>">Edit Staff</a>
    <a class="btn" href="<?=e(base_url('staff/id_card.php?id='.$id))?>">Generate ID Card</a>
  </div>
  <p class="small muted">The verification ID does not change when the staff record is edited. Keep the verification domain active, or redirect the old domain to the new one if you migrate.</p>
</section>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script>
(function(){
 const url = <?= json_encode($verificationUrl) ?>;
 const box = document.getElementById('qrcode');
 if (window.QRCode) {
   new QRCode(box, {text:url,width:220,height:220,correctLevel:QRCode.CorrectLevel.M});
   document.getElementById('downloadQr').addEventListener('click', function(){
     const canvas=box.querySelector('canvas');
     const img=box.querySelector('img');
     const src=canvas ? canvas.toDataURL('image/png') : (img ? img.src : '');
     if(!src){ alert('QR is not ready yet.'); return; }
     const a=document.createElement('a'); a.href=src; a.download='SVP-<?=e($s['staff_id'])?>-QR.png'; a.click();
   });
 } else {
   box.innerHTML='<div class="alert">QR generator could not load. Check your internet connection and refresh the page.</div>';
 }
})();
</script>
<?php include __DIR__.'/../includes/footer.php'; ?>
