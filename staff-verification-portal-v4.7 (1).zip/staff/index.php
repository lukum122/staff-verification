<?php
require_once __DIR__.'/../config/config.php'; require_once __DIR__.'/../config/database.php'; require_once __DIR__.'/../includes/auth.php'; require_once __DIR__.'/../includes/functions.php'; require_admin();
$q=trim($_GET['q']??'');
if($q!==''){
 $stmt=$pdo->prepare("SELECT s.*,c.name company_name FROM staff s INNER JOIN companies c ON c.id=s.company_id WHERE s.staff_id LIKE ? OR CONCAT(s.first_name,' ',s.last_name) LIKE ? OR c.name LIKE ? ORDER BY s.id DESC");
 $like='%'.$q.'%'; $stmt->execute([$like,$like,$like]); $rows=$stmt->fetchAll();
}else{
 $rows=$pdo->query("SELECT s.*,c.name company_name FROM staff s INNER JOIN companies c ON c.id=s.company_id ORDER BY s.id DESC LIMIT 200")->fetchAll();
}
?>
<?php $page_title='Staff'; include __DIR__.'/../includes/header.php'; ?>
<div class="page-head"><h1>Staff</h1><a class="btn" href="<?=e(base_url('staff/add.php'))?>">+ Add Staff</a></div>
<form class="search admin-search" method="get"><input name="q" placeholder="Search name, Staff ID or company" value="<?=e($q)?>"><button type="submit">SEARCH</button></form>
<div class="table-wrap"><table class="table"><tr><th>Name</th><th>Company</th><th>Staff ID</th><th>Position</th><th>Status</th><th>Action</th></tr>
<?php foreach($rows as $r): ?><tr><td><?=e(trim($r['first_name'].' '.($r['middle_name'] ?? '').' '.$r['last_name']))?></td><td><?=e($r['company_name'])?></td><td><?=e($r['staff_id'])?></td><td><?=e($r['position'])?></td><td><?=status_badge($r['status'])?></td><td><a href="<?=e(base_url('staff/view.php?id='.$r['id']))?>">View</a></td></tr><?php endforeach;?>
<?php if(!$rows): ?><tr><td colspan="6" class="empty">No staff records found.</td></tr><?php endif; ?></table></div>
<?php include __DIR__.'/../includes/footer.php'; ?>
