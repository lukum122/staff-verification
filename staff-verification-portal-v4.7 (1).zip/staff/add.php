<?php
require_once __DIR__.'/../config/config.php'; require_once __DIR__.'/../config/database.php'; require_once __DIR__.'/../includes/auth.php'; require_once __DIR__.'/../includes/functions.php'; require_admin();

$companies=$pdo->query("SELECT id,name FROM companies WHERE status='active' ORDER BY name")->fetchAll();
$error=''; $selected=(int)($_GET['company_id']??0);

if($_SERVER['REQUEST_METHOD']==='POST'){
 verify_csrf($_POST['csrf_token']??null);
 try{
  $companyId=(int)($_POST['company_id']??0);
  $first=trim($_POST['first_name']??''); $middle=trim($_POST['middle_name']??''); $last=trim($_POST['last_name']??'');
  $staffId=clean_staff_id($_POST['staff_id']??''); $position=trim($_POST['position']??'');
  if(!$companyId || !$first || !$last || !$staffId || !$position) throw new RuntimeException('Company, first name, last name, Staff ID and position are required.');

  $check=$pdo->prepare("SELECT id FROM companies WHERE id=? AND status='active'");$check->execute([$companyId]);
  if(!$check->fetch()) throw new RuntimeException('Selected company is not active.');

  $dup=$pdo->prepare("SELECT id FROM staff WHERE company_id=? AND staff_id=? LIMIT 1");$dup->execute([$companyId,$staffId]);
  if($dup->fetch()) throw new RuntimeException('That Staff ID already exists under this company.');

  do {
    $token=generate_verification_token();
    $x=$pdo->prepare("SELECT id FROM staff WHERE verification_token=?");$x->execute([$token]);
  } while($x->fetch());

  $photo=save_uploaded_image($_FILES['photo']??[], 'staff');
  $photoCrop=trim((string)($_POST['photo_crop']??''));
  if($photoCrop==='') {
    $photoCrop=null;
  } else {
    $decodedCrop=json_decode($photoCrop,true);
    if(!is_array($decodedCrop)) throw new RuntimeException('Invalid photo crop data. Please refresh the page and try again.');
    $photoCrop=json_encode($decodedCrop,JSON_UNESCAPED_SLASHES);
  }
  $signature=save_uploaded_signature($_FILES['signature']??[]);
  $stmt=$pdo->prepare("INSERT INTO staff(company_id,staff_id,verification_token,first_name,middle_name,last_name,photo,photo_crop,signature,position,department,phone,email,date_employed,expiry_date,status) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
  $stmt->execute([$companyId,$staffId,$token,$first,$middle,$last,$photo,$photoCrop,$signature,$position,trim($_POST['department']??''),trim($_POST['phone']??''),trim($_POST['email']??''),trim((string)($_POST['date_employed']??''))?:null,trim((string)($_POST['expiry_date']??''))?:null,$_POST['status']??'active']);
  $id=(int)$pdo->lastInsertId();
  redirect('staff/view.php?id='.$id);
 }catch(Throwable $e){
  error_log('SVP Staff creation error: '.$e->getMessage());
  $error=$e->getMessage();
}
}
?>
<?php $page_title='Add Staff'; include __DIR__.'/../includes/header.php'; ?>
<div class="form-card"><h2>Add Staff</h2><?php if($error):?><div class="alert"><?=e($error)?></div><?php endif;?>
<?php if(!$companies): ?><div class="alert">Create an active company before adding staff.</div><?php else: ?>
<form method="post" enctype="multipart/form-data"><input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>">
<div class="field"><label>Company *</label><select name="company_id" required><option value="">Select company</option><?php foreach($companies as $c):?><option value="<?=$c['id']?>" <?=$selected===$c['id']?'selected':''?>><?=e($c['name'])?></option><?php endforeach;?></select></div>
<div class="two"><div class="field"><label>First Name *</label><input name="first_name" required></div><div class="field"><label>Middle Name</label><input name="middle_name"></div></div>
<div class="field"><label>Last Name *</label><input name="last_name" required></div>
<div class="field"><label>Staff ID *</label><input name="staff_id" required placeholder="e.g. ABC-001"></div>
<div class="field"><label>Position *</label><input name="position" required></div>
<div class="field"><label>Department</label><input name="department"></div>
<div class="field"><label>Staff Photo</label><input type="file" id="photoInput" name="photo" accept="image/jpeg,image/png,image/webp"><input type="hidden" id="photoCrop" name="photo_crop"><div class="small muted">Optional · adjust zoom, position and shape before saving.</div><div id="photoEditor" class="photo-editor" style="display:none"><div class="photo-editor-preview"><img id="photoPreview" alt="Photo preview"></div><div class="photo-editor-controls"><label>Zoom <input id="photoZoom" type="range" min="1" max="2.5" step="0.01" value="1"></label><label>Horizontal <input id="photoX" type="range" min="-30" max="30" value="0"></label><label>Vertical <input id="photoY" type="range" min="-30" max="30" value="0"></label><label>Shape <select id="photoShape"><option value="rectangle">Rectangle</option><option value="rounded" selected>Rounded Rectangle</option><option value="circle">Circle</option></select></label></div></div></div>
<div class="field"><label>Staff Signature <span class="muted">(Optional)</span></label><input type="file" name="signature" accept="image/jpeg,image/png,image/webp"><div class="small muted">Optional · the portal removes a plain/light background and saves the signature as a transparent PNG · max 2MB</div></div>
<div class="two"><div class="field"><label>Phone</label><input name="phone"></div><div class="field"><label>Email</label><input type="email" name="email"></div></div>
<div class="two"><div class="field"><label>Date Employed</label><input type="date" name="date_employed"></div><div class="field"><label>Expiry Date</label><input type="date" name="expiry_date"></div></div>
<div class="field"><label>Status</label><select name="status"><option value="active">Active</option><option value="inactive">Inactive</option></select></div>
<button class="btn full">Create Staff & Generate Verification ID</button></form><script>(function(){const i=document.getElementById('photoInput'),ed=document.getElementById('photoEditor'),im=document.getElementById('photoPreview'),z=document.getElementById('photoZoom'),x=document.getElementById('photoX'),y=document.getElementById('photoY'),sh=document.getElementById('photoShape'),h=document.getElementById('photoCrop');function a(){im.style.transform=`translate(${x.value}%,${y.value}%) scale(${z.value})`;im.style.borderRadius=sh.value==='circle'?'50%':(sh.value==='rounded'?'10px':'0');h.value=JSON.stringify({zoom:+z.value,x:+x.value,y:+y.value,shape:sh.value})}[z,x,y,sh].forEach(e=>e.addEventListener('input',a));i.addEventListener('change',()=>{const f=i.files&&i.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{im.src=r.result;ed.style.display='grid';a()};r.readAsDataURL(f)});})();</script><style>.photo-editor{grid-template-columns:220px 1fr;gap:14px;margin-top:12px;padding:12px;border:1px solid #dfe4ed;border-radius:12px;background:#f8fafc}.photo-editor-preview{width:220px;height:180px;background:#eef2f6;border-radius:10px;overflow:hidden;display:flex;align-items:center;justify-content:center}.photo-editor-preview img{width:100%;height:100%;object-fit:contain;transform-origin:center}.photo-editor-controls{display:flex;flex-direction:column;gap:10px}.photo-editor-controls label{font-size:12px;font-weight:700}.photo-editor-controls input[type=range]{width:100%}@media(max-width:600px){.photo-editor{grid-template-columns:1fr}.photo-editor-preview{width:100%}}</style>
<?php endif; ?></div>
<?php include __DIR__.'/../includes/footer.php'; ?>
