<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';

$code = clean_staff_id($_GET['code'] ?? '');
$error = '';
$matches = [];

if ($code !== '') {
    $stmt = $pdo->prepare(
        "SELECT s.id, s.staff_id, s.verification_token, s.first_name, s.last_name, c.name AS company_name
         FROM staff s
         INNER JOIN companies c ON c.id = s.company_id
         WHERE s.staff_id = ?
         ORDER BY c.name, s.id DESC"
    );
    $stmt->execute([$code]);
    $matches = $stmt->fetchAll();

    if (count($matches) === 1) {
        redirect('v/' . $matches[0]['verification_token']);
    }
    if (!$matches) {
        $error = 'No staff record was found for that Staff ID.';
    }
}
?>
<?php $page_title = 'Verify Staff'; include __DIR__.'/includes/header.php'; ?>
<section class="hero">
  <div class="svp-mark">SVP</div>
  <h1>Verify Staff Credentials</h1>
  <p>Scan the QR code on a staff ID card, or enter the Staff ID below to confirm the current staff record.</p>

  <?php if ($error): ?><div class="alert"><?= e($error) ?></div><?php endif; ?>

  <form class="search" method="get">
    <input name="code" placeholder="Enter Staff ID" value="<?= e($code) ?>" autocomplete="off" required>
    <button type="submit">VERIFY</button>
  </form>

  <?php if (count($matches) > 1): ?>
    <div class="card result-list">
      <h3>More than one company uses this Staff ID</h3>
      <p class="muted">Select the company printed on the staff member's ID card.</p>
      <?php foreach ($matches as $m): ?>
        <a class="result-item" href="<?= e(base_url('v/' . $m['verification_token'])) ?>">
          <strong><?= e($m['company_name']) ?></strong>
          <span><?= e(trim($m['first_name'].' '.($m['middle_name'] ?? '').' '.$m['last_name'])) ?> · <?= e($m['staff_id']) ?></span>
        </a>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>

  <div class="feature-grid">
    <div><strong>Fast</strong><span>Scan the QR on the ID card.</span></div>
    <div><strong>Simple</strong><span>Enter a Staff ID when QR is unavailable.</span></div>
    <div><strong>Secure</strong><span>Public pages show verification details only.</span></div>
  </div>
</section>
<?php include __DIR__.'/includes/footer.php'; ?>
