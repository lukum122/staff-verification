CREATE TABLE IF NOT EXISTS id_card_templates (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  company_id INT UNSIGNED NULL,
  name VARCHAR(190) NOT NULL,
  category VARCHAR(80) NOT NULL DEFAULT 'General',
  orientation ENUM('portrait','landscape') NOT NULL DEFAULT 'portrait',
  front_image VARCHAR(255) NULL,
  back_image VARCHAR(255) NULL,
  front_layout JSON NULL,
  back_layout JSON NULL,
  is_builtin TINYINT(1) NOT NULL DEFAULT 0,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_template_company FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE ON UPDATE CASCADE,
  INDEX idx_template_company (company_id),
  INDEX idx_template_category (category),
  INDEX idx_template_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO id_card_templates (company_id,name,category,orientation,is_builtin,is_active,front_layout,back_layout)
SELECT NULL,'Corporate','Corporate','portrait',1,1,
'{"photo":{"x":18,"y":25,"w":30,"h":32},"name":{"x":52,"y":27,"w":43,"h":8,"fontSize":22,"align":"left"},"staff_id":{"x":52,"y":38,"w":43,"h":6,"fontSize":13,"align":"left"},"position":{"x":52,"y":46,"w":43,"h":6,"fontSize":12,"align":"left"},"department":{"x":52,"y":54,"w":43,"h":6,"fontSize":11,"align":"left"},"qr":{"x":62,"y":69,"w":24,"h":24}}',NULL
WHERE NOT EXISTS (SELECT 1 FROM id_card_templates WHERE company_id IS NULL AND name='Corporate');

INSERT INTO id_card_templates (company_id,name,category,orientation,is_builtin,is_active,front_layout,back_layout)
SELECT NULL,'Logistics & Security','Logistics / Security','portrait',1,1,
'{"photo":{"x":10,"y":23,"w":38,"h":34},"name":{"x":53,"y":27,"w":40,"h":8,"fontSize":21,"align":"left"},"staff_id":{"x":53,"y":38,"w":40,"h":6,"fontSize":13,"align":"left"},"position":{"x":53,"y":47,"w":40,"h":6,"fontSize":12,"align":"left"},"department":{"x":53,"y":56,"w":40,"h":6,"fontSize":11,"align":"left"},"qr":{"x":68,"y":71,"w":21,"h":21}}',NULL
WHERE NOT EXISTS (SELECT 1 FROM id_card_templates WHERE company_id IS NULL AND name='Logistics & Security');

INSERT INTO id_card_templates (company_id,name,category,orientation,is_builtin,is_active,front_layout,back_layout)
SELECT NULL,'School & Institution','School / Institution','portrait',1,1,
'{"photo":{"x":22,"y":23,"w":56,"h":32},"name":{"x":10,"y":59,"w":80,"h":8,"fontSize":21,"align":"center"},"staff_id":{"x":10,"y":69,"w":38,"h":6,"fontSize":12,"align":"left"},"position":{"x":52,"y":69,"w":38,"h":6,"fontSize":12,"align":"left"},"department":{"x":10,"y":78,"w":80,"h":6,"fontSize":11,"align":"center"},"qr":{"x":35,"y":86,"w":30,"h":10}}',NULL
WHERE NOT EXISTS (SELECT 1 FROM id_card_templates WHERE company_id IS NULL AND name='School & Institution');

INSERT INTO id_card_templates (company_id,name,category,orientation,is_builtin,is_active,front_layout,back_layout)
SELECT NULL,'Automobile / Motor Dealer','Automobile / Motor Dealer','portrait',1,1,
'{"photo":{"x":10,"y":27,"w":35,"h":34},"name":{"x":50,"y":29,"w":42,"h":8,"fontSize":20,"align":"left"},"staff_id":{"x":50,"y":40,"w":42,"h":6,"fontSize":12,"align":"left"},"position":{"x":50,"y":49,"w":42,"h":6,"fontSize":12,"align":"left"},"department":{"x":50,"y":58,"w":42,"h":6,"fontSize":11,"align":"left"},"qr":{"x":68,"y":72,"w":20,"h":20}}',NULL
WHERE NOT EXISTS (SELECT 1 FROM id_card_templates WHERE company_id IS NULL AND name='Automobile / Motor Dealer');

INSERT INTO id_card_templates (company_id,name,category,orientation,is_builtin,is_active,front_layout,back_layout)
SELECT NULL,'Agriculture / Agro','Agriculture / Agro','portrait',1,1,
'{"photo":{"x":19,"y":23,"w":62,"h":31},"name":{"x":8,"y":58,"w":84,"h":8,"fontSize":20,"align":"center"},"staff_id":{"x":8,"y":68,"w":38,"h":6,"fontSize":12,"align":"left"},"position":{"x":52,"y":68,"w":40,"h":6,"fontSize":12,"align":"left"},"department":{"x":8,"y":77,"w":84,"h":6,"fontSize":11,"align":"center"},"qr":{"x":35,"y":85,"w":30,"h":11}}',NULL
WHERE NOT EXISTS (SELECT 1 FROM id_card_templates WHERE company_id IS NULL AND name='Agriculture / Agro');

INSERT INTO id_card_templates (company_id,name,category,orientation,is_builtin,is_active,front_layout,back_layout)
SELECT NULL,'Modern Professional','Modern','landscape',1,1,
'{"photo":{"x":7,"y":20,"w":28,"h":60},"name":{"x":40,"y":24,"w":34,"h":10,"fontSize":22,"align":"left"},"staff_id":{"x":40,"y":39,"w":34,"h":7,"fontSize":13,"align":"left"},"position":{"x":40,"y":50,"w":34,"h":7,"fontSize":12,"align":"left"},"department":{"x":40,"y":61,"w":34,"h":7,"fontSize":11,"align":"left"},"qr":{"x":78,"y":28,"w":17,"h":28}}',NULL
WHERE NOT EXISTS (SELECT 1 FROM id_card_templates WHERE company_id IS NULL AND name='Modern Professional');

ALTER TABLE companies ADD COLUMN id_card_template_id INT UNSIGNED NULL AFTER registration_number;
ALTER TABLE companies ADD INDEX idx_company_template (id_card_template_id);
