V2.2 ID CARD TEMPLATE ARCHITECTURE

- Built-in templates: Corporate, Logistics & Security, School & Institution, Automobile / Motor Dealer, Agriculture / Agro, Modern Professional.
- Both portrait and landscape are supported.
- Companies can later have custom templates uploaded as image backgrounds.
- Template layouts are JSON field positions in percentage coordinates, making them independent of output pixel size.
- A future template-management UI can add unlimited custom templates without changing staff records.
- Staff verification_token remains the QR source and never changes when card designs change.
