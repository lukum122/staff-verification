<?php
declare(strict_types=1);

const APP_NAME = 'Staff Verification Portal';
const APP_SHORT_NAME = 'SVP';

/*
 * CHANGE THIS to the public URL of your installation.
 * Example: https://verify.example.com
 * No trailing slash.
 */
const BASE_URL = 'https://staffverification.owode.ng';

const UPLOAD_DIR = __DIR__ . '/../uploads/';
const MAX_UPLOAD_SIZE = 2 * 1024 * 1024; // 2MB
const ALLOWED_IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp'];

date_default_timezone_set('Africa/Lagos');

ini_set('session.use_strict_mode', '1');
ini_set('session.cookie_httponly', '1');
ini_set('session.cookie_samesite', 'Lax');
if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
    ini_set('session.cookie_secure', '1');
}
