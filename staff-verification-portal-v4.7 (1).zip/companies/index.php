<?php
require_once __DIR__.'/../config/config.php'; require_once __DIR__.'/../config/database.php'; require_once __DIR__.'/../includes/auth.php'; require_once __DIR__.'/../includes/functions.php'; require_admin();
$rows=$pdo->query("SELECT c.*,COUNT(s.id) staff_count FROM companies c LEFT JOIN staff s ON s.company_id=c.id GROUP BY c.id ORDER BY c.id DESC")->fetchAll();
?>
<?php $page_title='Companies'; include __DIR__.'/../includes/header.php'; ?>
<div class="page-head"><h1>Companies</h1><a class="btn" href="<?= e(base_url('companies/add.php')) ?>">+ Add Company</a></div>
<div class="table-wrap"><table class="table"><tr><th>Company</th><th>Staff</th><th>Status</th><th>Action</th></tr>
<?php foreach($rows as $r): ?>
<tr><td><?=e($r['name'])?></td><td><?=e((string)$r['staff_count'])?></td><td><?=status_badge($r['status'])?></td><td><a href="<?=e(base_url('companies/view.php?id='.$r['id']))?>">View</a></td></tr>
<?php endforeach; ?>
<?php if(!$rows): ?><tr><td colspan="4" class="empty">No companies yet.</td></tr><?php endif; ?></table></div>
<?php include __DIR__.'/../includes/footer.php'; ?>
