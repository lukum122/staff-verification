<?php
require_once __DIR__.'/../config/config.php'; require_once __DIR__.'/../config/database.php'; require_once __DIR__.'/../includes/auth.php'; require_once __DIR__.'/../includes/functions.php'; require_admin();
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 verify_csrf($_POST['csrf_token']??null);
 try{
  $name=trim($_POST['name']??'');
  if($name==='') throw new RuntimeException('Company name is required.');
  $logo=save_uploaded_logo($_FILES['logo']??[], 'companies');
  $stmt=$pdo->prepare("INSERT INTO companies(name,logo,address,phone,email,website,registration_number,status) VALUES(?,?,?,?,?,?,?,?)");
  $stmt->execute([$name,$logo,trim($_POST['address']??''),trim($_POST['phone']??''),trim($_POST['email']??''),trim($_POST['website']??''),trim($_POST['registration_number']??''),$_POST['status']??'active']);
  redirect('companies/index.php');
 }catch(Throwable $e){
  error_log('SVP Company creation error: '.$e->getMessage());
  $error=$e->getMessage();
}
}
?>
<?php $page_title='Add Company'; include __DIR__.'/../includes/header.php'; ?>
<div class="form-card"><h2>Add Company</h2><?php if($error):?><div class="alert"><?=e($error)?></div><?php endif;?>
<form method="post" enctype="multipart/form-data"><input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>">
<div class="field"><label>Company Name *</label><input name="name" required></div>
<div class="field"><label>Company Logo</label><input type="file" name="logo" accept="image/jpeg,image/png,image/webp"><div class="small muted">JPG, PNG or WEBP · max 2MB</div></div>
<div class="field"><label>Address</label><input name="address"></div>
<div class="field"><label>Phone</label><input name="phone"></div>
<div class="field"><label>Email</label><input type="email" name="email"></div>
<div class="field"><label>Website</label><input name="website"></div>
<div class="field"><label>Registration Number</label><input name="registration_number"></div>
<div class="field"><label>Status</label><select name="status"><option value="active">Active</option><option value="inactive">Inactive</option></select></div>
<button class="btn">Save Company</button></form></div>
<?php include __DIR__.'/../includes/footer.php'; ?>
