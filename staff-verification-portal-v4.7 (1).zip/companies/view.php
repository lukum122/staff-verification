<?php
require_once __DIR__.'/../config/config.php'; require_once __DIR__.'/../config/database.php'; require_once __DIR__.'/../includes/auth.php'; require_once __DIR__.'/../includes/functions.php'; require_admin();
$id=(int)($_GET['id']??0);
$stmt=$pdo->prepare("SELECT * FROM companies WHERE id=?");$stmt->execute([$id]);$company=$stmt->fetch();
if(!$company){http_response_code(404);exit('Company not found.');}

if($_SERVER['REQUEST_METHOD']==='POST'){
 verify_csrf($_POST['csrf_token']??null);
 $action=$_POST['action']??'';
 if($action==='toggle'){
   $new=$company['status']==='active'?'inactive':'active';
   $pdo->prepare("UPDATE companies SET status=? WHERE id=?")->execute([$new,$id]);
   redirect('companies/view.php?id='.$id);
 }
 if($action==='template'){
   $templateId=(int)($_POST['template_id']??0);
   $pdo->prepare("UPDATE companies SET id_card_template_id=? WHERE id=?")->execute([$templateId?:null,$id]);
   redirect('companies/view.php?id='.$id);
 }
}
$templates=$pdo->query("SELECT id,name,category,orientation,is_builtin FROM id_card_templates WHERE is_active=1 ORDER BY is_builtin DESC,name")->fetchAll();
$stmt=$pdo->prepare("SELECT * FROM staff WHERE company_id=? ORDER BY id DESC");$stmt->execute([$id]);$staff=$stmt->fetchAll();
?>
<?php $page_title=$company['name']; include __DIR__.'/../includes/header.php'; ?>
<div class="page-head"><div><h1><?=e($company['name'])?></h1><div class="muted"><?=e($company['address']??'')?></div></div><a class="btn" href="<?=e(base_url('staff/add.php?company_id='.$id))?>">+ Add Staff</a></div>
<div class="card">
<p><strong>Phone:</strong> <?=e($company['phone']??'—')?> &nbsp; <strong>Email:</strong> <?=e($company['email']??'—')?></p>
<p><strong>Status:</strong> <?=status_badge($company['status'])?></p>
<a class="btn secondary" href="<?=e(base_url('templates/index.php?company_id='.$id))?>">Customize ID Card</a>
<form method="post" class="inline-form"><input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="template"><label><strong>ID Card Template</strong></label><select name="template_id" style="max-width:420px;margin:6px 0 10px;padding:10px;border:1px solid #d8deea;border-radius:10px"><option value="0">Use no template yet</option><?php foreach($templates as $t):?><option value="<?=$t['id']?>" <?=$company['id_card_template_id']==$t['id']?'selected':''?>><?=e($t['name'].' · '.ucfirst($t['orientation']))?></option><?php endforeach;?></select><button class="btn secondary" type="submit">Save ID Card Template</button></form>
<form method="post" class="inline-form"><input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="toggle"><button class="btn secondary" type="submit"><?= $company['status']==='active'?'Deactivate Company':'Activate Company' ?></button></form>
</div>
<div class="card" style="margin-top:20px"><h3>Staff</h3><div class="table-wrap"><table class="table"><tr><th>Name</th><th>Staff ID</th><th>Position</th><th>Status</th><th>Action</th></tr>
<?php foreach($staff as $s):?><tr><td><?=e(trim($s['first_name'].' '.($s['middle_name'] ?? '').' '.$s['last_name']))?></td><td><?=e($s['staff_id'])?></td><td><?=e($s['position'])?></td><td><?=status_badge($s['status'])?></td><td><a href="<?=e(base_url('staff/view.php?id='.$s['id']))?>">View</a></td></tr><?php endforeach;?>
<?php if(!$staff):?><tr><td colspan="5" class="empty">No staff added.</td></tr><?php endif;?></table></div></div>
<?php include __DIR__.'/../includes/footer.php'; ?>
