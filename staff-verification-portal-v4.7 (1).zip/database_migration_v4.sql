-- SVP v4.0 — ID Card subsystem rebuild
-- Safe to run on the existing database: companies, staff, admins and
-- verification_logs are untouched. Only id_card_templates is replaced.
--
-- The old table (and any leftover duplicate/legacy rows from earlier
-- versions) is dropped and recreated with a design_key column, so built-in
-- templates are matched by a stored key instead of fragile name-matching.
-- Built-in rows are seeded automatically by the app (seed_builtin_templates)
-- the next time any admin page loads — no manual INSERTs needed here.

DROP TABLE IF EXISTS id_card_templates;

CREATE TABLE id_card_templates (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  company_id INT UNSIGNED NULL,
  design_key VARCHAR(40) NULL,
  name VARCHAR(190) NOT NULL,
  category VARCHAR(80) NOT NULL DEFAULT 'General',
  orientation ENUM('portrait','landscape') NOT NULL DEFAULT 'portrait',
  front_image VARCHAR(255) NULL,
  back_image VARCHAR(255) NULL,
  front_layout JSON NULL,
  back_layout JSON NULL,
  is_builtin TINYINT(1) NOT NULL DEFAULT 0,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_template_company FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE ON UPDATE CASCADE,
  INDEX idx_template_company (company_id),
  INDEX idx_template_design (design_key),
  INDEX idx_template_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Old template IDs no longer exist; clear any company assignment so the
-- generator falls back to the default built-in template until reassigned.
UPDATE companies SET id_card_template_id = NULL;
