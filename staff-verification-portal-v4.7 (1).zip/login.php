<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';

if (!empty($_SESSION['admin_id'])) redirect('dashboard.php');

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf($_POST['csrf_token'] ?? null);
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $pdo->prepare("SELECT * FROM admins WHERE email = ? LIMIT 1");
    $stmt->execute([$email]);
    $admin = $stmt->fetch();

    if ($admin && password_verify($password, $admin['password_hash'])) {
        session_regenerate_id(true);
        $_SESSION['admin_id'] = $admin['id'];
        $_SESSION['admin_name'] = $admin['name'];
        redirect('dashboard.php');
    }
    $error = 'Invalid email or password.';
}
?>
<?php $page_title='Admin Login'; include __DIR__.'/includes/header.php'; ?>
<div class="form-card narrow">
  <div class="svp-mark">SVP</div>
  <h2>Administrator Login</h2>
  <p class="muted">Manage companies, staff records and verification activity.</p>
  <?php if ($error): ?><div class="alert"><?= e($error) ?></div><?php endif; ?>
  <form method="post">
    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
    <div class="field"><label>Email</label><input type="email" name="email" autocomplete="username" required></div>
    <div class="field"><label>Password</label><input type="password" name="password" autocomplete="current-password" required></div>
    <button class="btn full" type="submit">SIGN IN</button>
  </form>
</div>
<?php include __DIR__.'/includes/footer.php'; ?>
