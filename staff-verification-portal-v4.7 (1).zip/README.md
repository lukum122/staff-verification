V4.7 bug-fix release

- Fixed company creation failures caused by expensive GD logo processing on shared hosting. Logos now use the safe upload pipeline.
- Fixed staff creation JSON errors caused by inserting an empty string into the staff.photo_crop JSON column. Empty crop data is stored as NULL and non-empty crop data is validated.
- Applied the same photo_crop validation to staff editing.
- Added server-side error logging for company/staff creation failures without exposing secrets.

# Staff Verification Portal (SVP) — Version 4.0

Version 4.0 is a full rebuild of the ID-card subsystem: the template library,
the custom upload/editor, and the card generator. Admin login, company
management, staff management, QR verification-token generation, the public
`/v/TOKEN` verification page, and verification logs are **untouched** —
those were already working and are not part of this rebuild.

## Why this version exists

Versions 3.1–3.7 kept breaking in different ways (generic-looking built-in
templates, orientation bugs, a custom-upload canvas that stayed blank,
thumbnails that didn't match the real card) because the thumbnail preview,
the editor canvas, and the actual card generator were **three separate
implementations** that could drift out of sync. That's also why
`database.sql` had ended up with duplicate/legacy template rows from an even
older version.

V4.0 fixes the architecture, not just the symptoms:

- **One render engine** (`includes/id_card_engine.php`, function
  `render_card_face()`) is the only place a card's visual output is
  produced. The template library thumbnail, the editor's live preview, and
  the real staff card generator all call it with different data but
  identical code — if it looks right in one place, it looks right
  everywhere.
- **A redesigned `id_card_templates` table** with a `design_key` column, so
  built-in templates are matched by a stored key instead of fragile
  name-matching against a PHP array.
- **A genuinely live upload preview**: picking a file in the editor shows it
  on the canvas immediately via `templates/upload_asset.php`, instead of
  only appearing after you save and the page reloads.

## What's in V4.0

- QR code remains the core verification mechanism — every staff member gets
  a permanent token, and the front of the card carries a QR pointing to
  `https://staffverification.owode.ng/v/TOKEN`. (An earlier iteration of
  this rebuild explored a barcode-only approach; that was reverted — QR is
  the platform's foundation because it scans with any phone's stock camera
  app, which a linear barcode does not.)
- 10 built-in designs, each with its own field layout (not the same layout
  recoloured): Corporate Classic, Corporate Executive, Logistics Bold,
  Security Professional, School Modern, Automobile Pro, Agro Green, Farm
  Professional, Modern Minimal, Modern Split. Adding more later is one entry
  in `builtin_designs()` plus one `.design-<key>` CSS block — nothing else
  needs to change.
- Real portrait and landscape CR80 layouts; templates are not forced into
  landscape.
- Custom template upload for JPG/PNG/WEBP artwork, with automatic
  orientation detection from the image's actual dimensions, and an
  immediate on-canvas preview.
- Drag/resize field editor: add, move, resize, delete, change font size,
  weight, alignment, and colour (from the company's palette) for any field,
  on front or back.
- Built-in templates are immutable; "Customize" clones one into a
  company-owned, independently editable template.
- Company branding controls: primary/secondary/text/muted colours, card
  title, tagline, bottom slogan, website visibility, staff photo shape.
- Front: logo, company name, optional tagline, editable title, staff photo,
  full name, position, Staff ID, QR + label, optional bottom text.
- Back: logo/company name, important instructions, company
  address/phone/email, optional website, staff signature, issue/expiry
  dates, optional bottom text. No QR or barcode on the back.
- Forbidden fields stay excluded regardless of what a template's layout JSON
  contains: department, staff phone/email, home address, NIN, BVN, front
  signature.
- Staff photo crop settings (zoom, horizontal/vertical focal position, and
  an optional per-staff shape override) are read from `staff.photo_crop`;
  the original uploaded photo is never modified.
- Front PNG/JPG download, back PNG/JPG download, both-sides PDF, and print
  — output contains only the card, never the dashboard UI.

## Database

This version **replaces** the `id_card_templates` table. Run
`database_migration_v4.sql` on your existing database — it only touches
that one table (`companies`, `staff`, `verification_logs`, admins are
untouched) and clears `companies.id_card_template_id` since old template IDs
won't match the new table. Built-in templates reseed automatically the next
time any admin opens a template-related page — no manual SQL inserts
needed.

On a brand-new installation, import `database.sql` first, then
`database_migration_v4.sql`.

## Updating an existing installation

1. Back up the database and `uploads/`.
2. Replace application files with this package.
3. Run `database_migration_v4.sql`.
4. **Preserve your live `config/database.php`** so credentials aren't overwritten.
5. Preserve your existing `uploads/` folder.
6. Log in, open **ID Card Templates** for a company — the 10 built-ins seed automatically.
7. Re-assign a template per company (old assignments were cleared by the migration).
8. Open a staff record and generate the card to confirm it renders correctly end to end.

## Custom template workflow

1. Open **+ Upload Existing Card Design**.
2. Upload the front artwork — it appears on the canvas immediately, and
   orientation is detected from the image's actual dimensions.
3. Upload the back artwork if you have one.
4. Add fields from the toolbar, drag them into place, resize with the
   handle, and adjust font/color/alignment in the side panel.
5. Save. The template is stored for that company and becomes selectable
   from the library.

Supported artwork formats are JPG, PNG and WEBP. Flat PDF import isn't
included — reliable server-side PDF-to-image rendering isn't available on
lightweight shared hosting without adding another dependency.

## CR80

Landscape: 85.60 × 53.98 mm. Portrait: 53.98 × 85.60 mm.

## Security / deployment notes

- Use HTTPS.
- Keep the verification domain stable once cards are issued.
- Do not delete existing verification tokens.
- Delete `setup_admin.php` after initial setup if it's still present.
- Keep the `uploads/.htaccess` protection (no PHP execution in uploads).
- Do not store NIN, BVN or other sensitive information in public
  verification/card fields.

## Libraries

The admin card generator uses QRCode.js, html2canvas and jsPDF from cdnjs
for browser rendering/export. The public `/v/TOKEN` verification route does
not depend on any of these.

## A note on testing

I don't have a PHP interpreter or MySQL available in the environment this
package was built in, so I could not run a live end-to-end test of this
rebuild. Every file was checked for balanced syntax and cross-referenced
against the actual `companies`/`staff` schema, but please run `php -l` on
the changed files and generate one real test card (a good scenario: a
company with a logo, a staff member with a photo and signature, on both a
built-in and a custom-uploaded template) before relying on this in
production.


## v4.6 ID-card templates
- Uploaded PNG/JPEG artwork templates are no longer supported.
- Built-ins are structured object-based designs; the approved Agriculture / Agro composition is the visual reference.
- Decorative objects and dynamic fields can be moved/resized/rotated; colours can be changed.
- Staff QR is generated from the permanent verification token.
- Staff photo uses the saved focal/zoom crop and `object-fit: contain` so an untouched head is not automatically cut.
- Existing built-in rows are refreshed to the v4.6 layouts automatically.
