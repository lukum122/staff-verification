<?php
if (!isset($page_title)) $page_title = APP_NAME;
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="<?= !empty($_SESSION['admin_id']) ? 'noindex,nofollow' : 'noindex,nofollow' ?>">
<title><?= e($page_title) ?> · SVP</title>
<link rel="stylesheet" href="<?= e(base_url('assets/css/style.css')) ?>">
</head>
<body>
<?php if (!empty($_SESSION['admin_id'])): ?>
<header class="topbar">
  <a class="brand" href="<?= e(base_url('dashboard.php')) ?>"><span>SVP</span><small>Staff Verification Portal</small></a>
  <nav>
    <a href="<?= e(base_url('dashboard.php')) ?>">Dashboard</a>
    <a href="<?= e(base_url('companies/index.php')) ?>">Companies</a>
    <a href="<?= e(base_url('staff/index.php')) ?>">Staff</a>
    <a href="<?= e(base_url('logs/index.php')) ?>">Logs</a>
    <a href="<?= e(base_url('templates/index.php')) ?>">ID Templates</a>
    <a href="<?= e(base_url('logout.php')) ?>">Logout</a>
  </nav>
</header>
<?php endif; ?>
<main class="container">
