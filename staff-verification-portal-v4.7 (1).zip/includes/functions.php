<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/config.php';

function e(?string $value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function base_url(string $path = ''): string {
    return rtrim(BASE_URL, '/') . '/' . ltrim($path, '/');
}

function redirect(string $path): never {
    header('Location: ' . base_url($path));
    exit;
}

function generate_verification_token(): string {
    // URL-safe, non-sequential, permanent verification identifier.
    return strtoupper(rtrim(strtr(base64_encode(random_bytes(12)), '+/', '-_'), '='));
}

function save_uploaded_image(array $file, string $folder): ?string {
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return null;
    if (($file['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) {
        $code = (int)($file['error'] ?? UPLOAD_ERR_NO_FILE);
        $message = match ($code) {
            UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => 'Image is too large for the server upload limit. Try an image under 2MB.',
            UPLOAD_ERR_PARTIAL => 'Image upload was interrupted. Please try again.',
            UPLOAD_ERR_NO_TMP_DIR => 'Server upload folder is unavailable. Please contact hosting support.',
            UPLOAD_ERR_CANT_WRITE => 'Server could not save the uploaded image. Check the uploads folder permissions.',
            UPLOAD_ERR_EXTENSION => 'The server stopped the image upload. Please try another image.',
            default => 'Image upload failed.'
        };
        throw new RuntimeException($message);
    }
    if (($file['size'] ?? 0) > MAX_UPLOAD_SIZE) {
        throw new RuntimeException('Image is too large. Maximum size is 2MB.');
    }
    if (empty($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
        throw new RuntimeException('Invalid image upload.');
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($file['tmp_name']);
    if (!in_array($mime, ALLOWED_IMAGE_TYPES, true)) {
        throw new RuntimeException('Only JPG, PNG and WEBP images are allowed.');
    }

    $dir = UPLOAD_DIR . trim($folder, '/') . '/';
    if (!is_dir($dir) && !mkdir($dir, 0755, true) && !is_dir($dir)) {
        throw new RuntimeException('Could not create upload directory.');
    }

    $ext = match ($mime) {
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
        default => throw new RuntimeException('Unsupported image type.')
    };

    $name = bin2hex(random_bytes(16)) . '.' . $ext;
    if (!move_uploaded_file($file['tmp_name'], $dir . $name)) {
        throw new RuntimeException('Could not save image.');
    }

    return 'uploads/' . trim($folder, '/') . '/' . $name;
}


function save_uploaded_logo(array $file, string $folder = 'companies'): ?string {
    // Logos are stored safely without expensive per-pixel processing. The previous
    // implementation flood-filled every pixel of the uploaded image, which could
    // exhaust memory on shared hosting and result in a blank HTTP 500 response.
    // Transparent PNG/WEBP logos keep their transparency; JPG logos are stored as JPG.
    return save_uploaded_image($file, $folder);
}

function save_uploaded_signature(array $file, string $folder = 'staff/signatures'): ?string {
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return null;
    if (($file['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) {
        $code = (int)($file['error'] ?? UPLOAD_ERR_NO_FILE);
        $message = match ($code) {
            UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => 'Signature is too large for the server upload limit. Try an image under 2MB.',
            UPLOAD_ERR_PARTIAL => 'Signature upload was interrupted. Please try again.',
            UPLOAD_ERR_NO_TMP_DIR => 'Server upload folder is unavailable. Please contact hosting support.',
            UPLOAD_ERR_CANT_WRITE => 'Server could not save the signature. Check the uploads folder permissions.',
            UPLOAD_ERR_EXTENSION => 'The server stopped the signature upload. Please try another image.',
            default => 'Signature upload failed.'
        };
        throw new RuntimeException($message);
    }
    if (($file['size'] ?? 0) > MAX_UPLOAD_SIZE) throw new RuntimeException('Signature is too large. Maximum size is 2MB.');
    if (empty($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) throw new RuntimeException('Invalid signature upload.');

    if (!extension_loaded('gd')) {
        throw new RuntimeException('Signature background removal requires the PHP GD extension. Please enable GD in your hosting PHP settings.');
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($file['tmp_name']);
    if (!in_array($mime, ['image/jpeg','image/png','image/webp'], true)) {
        throw new RuntimeException('Only JPG, PNG and WEBP signature images are allowed.');
    }

    $src = match ($mime) {
        'image/jpeg' => @imagecreatefromjpeg($file['tmp_name']),
        'image/png' => @imagecreatefrompng($file['tmp_name']),
        'image/webp' => function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($file['tmp_name']) : false,
        default => false,
    };
    if (!$src) throw new RuntimeException('Could not read the signature image.');

    $w = imagesx($src); $h = imagesy($src);
    if ($w < 20 || $h < 10) { imagedestroy($src); throw new RuntimeException('Signature image is too small.'); }

    // Sample the four corners to estimate the paper/background color.
    $points = [[0,0],[$w-1,0],[0,$h-1],[$w-1,$h-1]];
    $bg=[0,0,0];
    foreach($points as [$x,$y]){
        $rgb=imagecolorat($src,$x,$y);
        $bg[0]+=($rgb>>16)&255; $bg[1]+=($rgb>>8)&255; $bg[2]+=$rgb&255;
    }
    $bg=array_map(fn($v)=>$v/4,$bg);

    $dst=imagecreatetruecolor($w,$h);
    imagealphablending($dst,false); imagesavealpha($dst,true);
    $transparent=imagecolorallocatealpha($dst,255,255,255,127);
    imagefill($dst,0,0,$transparent);

    $minX=$w; $minY=$h; $maxX=-1; $maxY=-1;
    for($y=0;$y<$h;$y++){
        for($x=0;$x<$w;$x++){
            $rgba=imagecolorat($src,$x,$y);
            $r=($rgba>>16)&255; $g=($rgba>>8)&255; $b=$rgba&255;
            $a=($rgba>>24)&127;
            $existingAlpha=127-$a;
            $dist=sqrt(($r-$bg[0])**2+($g-$bg[1])**2+($b-$bg[2])**2);
            $lum=(0.299*$r+0.587*$g+0.114*$b);

            // Plain light paper: turn near-white pixels transparent, while retaining anti-aliased ink.
            if($bg[0]>210 && $bg[1]>210 && $bg[2]>210){
                $ink=255-$lum;
                if($ink<=12){ $alpha=0; }
                else { $alpha=min(255,(int)round($ink*5.2)); }
            } else {
                // For a non-white background, remove pixels close to the sampled background color.
                if($dist<=22){ $alpha=0; }
                elseif($dist>=70){ $alpha=255; }
                else { $alpha=(int)round(($dist-22)/48*255); }
            }
            $alpha=(int)round($alpha*($existingAlpha/255));
            if($alpha<=2) continue;
            $gdAlpha=127-(int)round($alpha/255*127);
            $color=imagecolorallocatealpha($dst,$r,$g,$b,$gdAlpha);
            imagesetpixel($dst,$x,$y,$color);
            $minX=min($minX,$x); $minY=min($minY,$y); $maxX=max($maxX,$x); $maxY=max($maxY,$y);
        }
    }
    imagedestroy($src);

    if($maxX<0){ imagedestroy($dst); throw new RuntimeException('No signature was detected. Use a clear signature on a plain background.'); }

    $pad=max(3,(int)round(min($w,$h)*0.02));
    $minX=max(0,$minX-$pad); $minY=max(0,$minY-$pad); $maxX=min($w-1,$maxX+$pad); $maxY=min($h-1,$maxY+$pad);
    $cw=$maxX-$minX+1; $ch=$maxY-$minY+1;
    $crop=imagecreatetruecolor($cw,$ch);
    imagealphablending($crop,false); imagesavealpha($crop,true);
    $clear=imagecolorallocatealpha($crop,255,255,255,127); imagefill($crop,0,0,$clear);
    imagecopy($crop,$dst,0,0,$minX,$minY,$cw,$ch); imagedestroy($dst);

    $dir=UPLOAD_DIR.trim($folder,'/').'/';
    if(!is_dir($dir) && !mkdir($dir,0755,true) && !is_dir($dir)) { imagedestroy($crop); throw new RuntimeException('Could not create signature upload directory.'); }
    $name=bin2hex(random_bytes(16)).'.png';
    $path=$dir.$name;
    if(!imagepng($crop,$path,6)){ imagedestroy($crop); throw new RuntimeException('Could not save processed signature.'); }
    imagedestroy($crop);
    return 'uploads/'.trim($folder,'/').'/'.$name;
}

function delete_uploaded_file(?string $relativePath): void {
    if (!$relativePath) return;
    $root = realpath(UPLOAD_DIR);
    $file = realpath(__DIR__ . '/../' . ltrim($relativePath, '/'));
    if ($root && $file && str_starts_with($file, $root . DIRECTORY_SEPARATOR) && is_file($file)) {
        @unlink($file);
    }
}

function status_badge(string $status): string {
    $class = $status === 'active' ? 'success' : 'danger';
    return '<span class="badge badge-' . $class . '">' . e(strtoupper($status)) . '</span>';
}

function staff_is_currently_active(array $staff): bool {
    if (($staff['status'] ?? '') !== 'active') return false;
    if (!empty($staff['expiry_date']) && $staff['expiry_date'] < date('Y-m-d')) return false;
    return true;
}

function log_verification(PDO $pdo, ?int $staffId, ?int $companyId, ?string $token, string $result): void {
    $stmt = $pdo->prepare(
        "INSERT INTO verification_logs
        (staff_id, company_id, verification_token, result, ip_address, user_agent)
        VALUES (?, ?, ?, ?, ?, ?)"
    );
    $ip = $_SERVER['REMOTE_ADDR'] ?? null;
    $ua = substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 500);
    $stmt->execute([$staffId, $companyId, $token, $result, $ip, $ua]);
}

function clean_staff_id(string $value): string {
    return trim(preg_replace('/\s+/', ' ', $value));
}
