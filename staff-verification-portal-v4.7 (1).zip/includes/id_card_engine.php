<?php
declare(strict_types=1);

const CARD_LONG_MM = 85.60;
const CARD_SHORT_MM = 53.98;

function card_ratio(string $orientation): string { return $orientation === 'portrait' ? CARD_SHORT_MM.'/'.CARD_LONG_MM : CARD_LONG_MM.'/'.CARD_SHORT_MM; }
function safe_card_orientation(string $o): string { return in_array($o,['portrait','landscape'],true) ? $o : 'portrait'; }
function parse_layout($json): array { if (is_array($json)) return $json; $d=json_decode((string)$json,true); return is_array($d)?$d:[]; }

/** Structured templates: every visual component is an object. No uploaded artwork is used. */
function organic_front(): array {
    return [
      'bg'          => ['kind'=>'decor','shape'=>'background','x'=>0,'y'=>0,'w'=>100,'h'=>100,'color'=>'#ffffff','z'=>0],
      'green_panel'  => ['kind'=>'decor','shape'=>'organic_panel','x'=>-9,'y'=>-5,'w'=>118,'h'=>39,'color'=>'primary','z'=>1,'rotation'=>0],
      'white_header' => ['kind'=>'decor','shape'=>'header_cutout','x'=>6,'y'=>0,'w'=>88,'h'=>29,'color'=>'#ffffff','z'=>2],
      'lime_swoosh'  => ['kind'=>'decor','shape'=>'swoosh','x'=>61,'y'=>-2,'w'=>45,'h'=>42,'color'=>'secondary','z'=>3,'rotation'=>18,'opacity'=>.95],
      'green_leaf_1' => ['kind'=>'decor','shape'=>'leaf','x'=>73,'y'=>2,'w'=>18,'h'=>27,'color'=>'secondary','z'=>3,'rotation'=>-26,'opacity'=>.95],
      'green_leaf_2' => ['kind'=>'decor','shape'=>'leaf','x'=>80,'y'=>11,'w'=>12,'h'=>22,'color'=>'primary','z'=>3,'rotation'=>28,'opacity'=>.92],
      'green_leaf_left' => ['kind'=>'decor','shape'=>'leaf','x'=>-3,'y'=>11,'w'=>18,'h'=>22,'color'=>'primary','z'=>3,'rotation'=>-48,'opacity'=>.8],
      'logo'         => ['kind'=>'field','field'=>'logo','x'=>7,'y'=>5,'w'=>15,'h'=>10,'shape'=>'contain','z'=>5],
      'company_name' => ['kind'=>'field','field'=>'company_name','x'=>25,'y'=>5,'w'=>67,'h'=>8,'fontSize'=>12,'weight'=>'900','align'=>'left','color'=>'primary','z'=>5],
      'tagline'      => ['kind'=>'field','field'=>'tagline','x'=>25,'y'=>13,'w'=>67,'h'=>5,'fontSize'=>6.5,'weight'=>'500','align'=>'left','color'=>'primary','z'=>5],
      'title'        => ['kind'=>'field','field'=>'title','x'=>8,'y'=>18,'w'=>84,'h'=>6,'fontSize'=>7.2,'weight'=>'900','align'=>'center','color'=>'primary','z'=>5],
      'photo_frame'  => ['kind'=>'decor','shape'=>'photo_frame','x'=>26,'y'=>27,'w'=>48,'h'=>34,'color'=>'primary','z'=>3,'radius'=>2.2],
      'photo'        => ['kind'=>'field','field'=>'photo','x'=>27,'y'=>28,'w'=>46,'h'=>32,'shape'=>'rounded','z'=>5],
      'name'         => ['kind'=>'field','field'=>'name','x'=>8,'y'=>64,'w'=>84,'h'=>8,'fontSize'=>12.5,'weight'=>'900','align'=>'center','color'=>'text','z'=>5],
      'position'     => ['kind'=>'field','field'=>'position','x'=>8,'y'=>72.5,'w'=>84,'h'=>5,'fontSize'=>7,'weight'=>'700','align'=>'center','color'=>'primary','z'=>5],
      'id_pill'      => ['kind'=>'decor','shape'=>'pill','x'=>36,'y'=>79,'w'=>28,'h'=>6,'color'=>'primary','z'=>3],
      'staff_id'     => ['kind'=>'field','field'=>'staff_id','x'=>36,'y'=>79,'w'=>28,'h'=>6,'fontSize'=>7,'weight'=>'900','align'=>'center','color'=>'white','z'=>5],
      'staff_id_label'=>['kind'=>'field','field'=>'staff_id_label','x'=>38,'y'=>85,'w'=>24,'h'=>3.5,'fontSize'=>5,'weight'=>'600','align'=>'center','color'=>'muted','z'=>5],
      'qr'           => ['kind'=>'field','field'=>'qr','x'=>44,'y'=>85.5,'w'=>12,'h'=>12,'shape'=>'qr','z'=>5],
      'qr_label'     => ['kind'=>'field','field'=>'qr_label','x'=>35,'y'=>97.5,'w'=>30,'h'=>2.3,'fontSize'=>4.2,'weight'=>'800','align'=>'center','color'=>'text','z'=>5],
      'bottom_band'  => ['kind'=>'decor','shape'=>'bottom_band','x'=>0,'y'=>96,'w'=>100,'h'=>4,'color'=>'primary','z'=>1],
      'bottom_text'  => ['kind'=>'field','field'=>'bottom_text','x'=>8,'y'=>96.1,'w'=>84,'h'=>3.3,'fontSize'=>4.7,'weight'=>'700','align'=>'center','color'=>'white','z'=>5],
    ];
}
function organic_back(): array {
    return [
      'bg'=>['kind'=>'decor','shape'=>'background','x'=>0,'y'=>0,'w'=>100,'h'=>100,'color'=>'#ffffff','z'=>0],
      'green_panel'=>['kind'=>'decor','shape'=>'organic_panel','x'=>-10,'y'=>-5,'w'=>120,'h'=>36,'color'=>'primary','z'=>1],
      'white_header'=>['kind'=>'decor','shape'=>'header_cutout','x'=>6,'y'=>0,'w'=>88,'h'=>29,'color'=>'#ffffff','z'=>2],
      'lime_swoosh'=>['kind'=>'decor','shape'=>'swoosh','x'=>60,'y'=>-2,'w'=>46,'h'=>35,'color'=>'secondary','z'=>3,'rotation'=>18,'opacity'=>.95],
      'green_leaf_1'=>['kind'=>'decor','shape'=>'leaf','x'=>73,'y'=>2,'w'=>18,'h'=>25,'color'=>'secondary','z'=>3,'rotation'=>-26],
      'green_leaf_2'=>['kind'=>'decor','shape'=>'leaf','x'=>80,'y'=>10,'w'=>12,'h'=>21,'color'=>'primary','z'=>3,'rotation'=>28],
      'green_leaf_left'=>['kind'=>'decor','shape'=>'leaf','x'=>-3,'y'=>11,'w'=>18,'h'=>21,'color'=>'primary','z'=>3,'rotation'=>-48],
      'logo'=>['kind'=>'field','field'=>'logo','x'=>7,'y'=>5,'w'=>15,'h'=>10,'shape'=>'contain','z'=>5],
      'company_name'=>['kind'=>'field','field'=>'company_name','x'=>25,'y'=>5,'w'=>67,'h'=>8,'fontSize'=>12,'weight'=>'900','align'=>'left','color'=>'primary','z'=>5],
      'tagline'=>['kind'=>'field','field'=>'tagline','x'=>25,'y'=>13,'w'=>67,'h'=>5,'fontSize'=>6.5,'weight'=>'500','align'=>'left','color'=>'primary','z'=>5],
      'important_pill'=>['kind'=>'decor','shape'=>'pill','x'=>8,'y'=>21,'w'=>30,'h'=>6,'color'=>'primary','z'=>3],
      'important_title'=>['kind'=>'field','field'=>'important_title','x'=>8,'y'=>21,'w'=>30,'h'=>6,'fontSize'=>6.5,'weight'=>'900','align'=>'center','color'=>'white','z'=>5],
      'important'=>['kind'=>'field','field'=>'important','x'=>8,'y'=>28,'w'=>84,'h'=>25,'fontSize'=>6.2,'weight'=>'500','align'=>'left','color'=>'text','z'=>5],
      'divider'=>['kind'=>'decor','shape'=>'line','x'=>8,'y'=>54,'w'=>84,'h'=>.5,'color'=>'#98a2b3','z'=>3],
      'contact_title'=>['kind'=>'field','field'=>'contact_title','x'=>8,'y'=>56,'w'=>40,'h'=>5,'fontSize'=>6.5,'weight'=>'900','align'=>'left','color'=>'primary','z'=>5],
      'contact'=>['kind'=>'field','field'=>'contact','x'=>8,'y'=>62,'w'=>53,'h'=>19,'fontSize'=>6.2,'weight'=>'500','align'=>'left','color'=>'text','z'=>5],
      'signature'=>['kind'=>'field','field'=>'signature','x'=>67,'y'=>63,'w'=>25,'h'=>11,'shape'=>'contain','z'=>5],
      'signature_line'=>['kind'=>'decor','shape'=>'line','x'=>67,'y'=>75,'w'=>25,'h'=>.5,'color'=>'#667085','z'=>3],
      'signature_label'=>['kind'=>'field','field'=>'signature_label','x'=>67,'y'=>76,'w'=>25,'h'=>4,'fontSize'=>5.5,'weight'=>'800','align'=>'center','color'=>'primary','z'=>5],
      'dates'=>['kind'=>'field','field'=>'dates','x'=>8,'y'=>83,'w'=>84,'h'=>5,'fontSize'=>5.5,'weight'=>'600','align'=>'center','color'=>'text','z'=>5],
      'bottom_band'=>['kind'=>'decor','shape'=>'bottom_band','x'=>0,'y'=>95,'w'=>100,'h'=>5,'color'=>'primary','z'=>1],
      'back_bottom'=>['kind'=>'field','field'=>'back_bottom','x'=>8,'y'=>95.5,'w'=>84,'h'=>3.5,'fontSize'=>4.7,'weight'=>'700','align'=>'center','color'=>'white','z'=>5],
      'back_leaf'=>['kind'=>'decor','shape'=>'leaf_cluster','x'=>73,'y'=>77,'w'=>24,'h'=>22,'color'=>'secondary','z'=>2,'rotation'=>-10,'opacity'=>.2],
    ];
}

function generic_variant(string $name,string $category,string $orientation,string $p,string $s): array {
    $front=organic_front(); $back=organic_back();
    // Keep the approved composition, but make the built-in library meaningfully varied.
    if ($name==='Corporate Executive') {
        foreach ([$front,$back] as &$arr) { $arr['green_panel']['shape']='diagonal_panel'; $arr['green_panel']['color']='primary'; $arr['lime_swoosh']['opacity']=.7; } unset($arr);
        $front['photo_frame']['shape']='photo_frame'; $front['photo_frame']['x']=7; $front['photo_frame']['w']=30; $front['photo']['x']=8; $front['photo']['w']=28; $front['name']['x']=42; $front['name']['w']=50; $front['name']['align']='left'; $front['position']['x']=42; $front['position']['w']=50; $front['staff_id']['x']=42; $front['staff_id']['w']=28; $front['qr']['x']=75; $front['qr']['y']=78; $front['qr']['w']=17; $front['qr']['h']=17; $front['qr_label']['x']=72; $front['qr_label']['y']=95; $front['qr_label']['w']=24; $front['bottom_band']['y']=96;
        return ['name'=>$name,'category'=>$category,'orientation'=>$orientation,'front'=>$front,'back'=>$back];
    }
    if ($name==='Logistics Bold') {
        $front['green_panel']['shape']='diagonal_panel'; $front['lime_swoosh']['shape']='swoosh'; $front['photo_frame']['x']=8; $front['photo_frame']['y']=30; $front['photo_frame']['w']=30; $front['photo_frame']['h']=48; $front['photo']['x']=9; $front['photo']['y']=31; $front['photo']['w']=28; $front['photo']['h']=46; $front['name']['x']=42; $front['name']['y']=34; $front['name']['w']=50; $front['name']['align']='left'; $front['position']['x']=42; $front['position']['y']=44; $front['position']['w']=50; $front['staff_id']['x']=42; $front['staff_id']['y']=52; $front['staff_id']['w']=30; $front['qr']['x']=76; $front['qr']['y']=66; $front['qr']['w']=16; $front['qr']['h']=16; $front['qr_label']['x']=72; $front['qr_label']['y']=83; $front['qr_label']['w']=24; return ['name'=>$name,'category'=>$category,'orientation'=>$orientation,'front'=>$front,'back'=>$back];
    }
    if ($name==='Security Professional') { $front['green_panel']['shape']='security_band'; $front['photo_frame']['shape']='circle_frame'; $front['photo']['shape']='circle'; $front['photo_frame']['x']=27; $front['photo_frame']['y']=28; $front['photo_frame']['w']=46; $front['photo_frame']['h']=40; $front['photo']['x']=28; $front['photo']['y']=29; $front['photo']['w']=44; $front['photo']['h']=38; $front['name']['y']=70; $front['position']['y']=79; $front['staff_id']['y']=86; $front['qr']['x']=80; $front['qr']['y']=84; $front['qr']['w']=12; $front['qr']['h']=12; return ['name'=>$name,'category'=>$category,'orientation'=>'portrait','front'=>$front,'back'=>$back]; }
    if ($name==='School Modern') { $front['green_panel']['shape']='school_band'; $front['photo_frame']['x']=20; $front['photo_frame']['y']=28; $front['photo_frame']['w']=60; $front['photo_frame']['h']=34; $front['photo']['x']=21; $front['photo']['y']=29; $front['photo']['w']=58; $front['photo']['h']=32; $front['name']['y']=66; $front['position']['y']=75; $front['staff_id']['y']=82; $front['qr']['x']=76; $front['qr']['y']=81; $front['qr']['w']=14; $front['qr']['h']=14; return ['name'=>$name,'category'=>$category,'orientation'=>'portrait','front'=>$front,'back'=>$back]; }
    if ($name==='Automobile Pro') { $front['green_panel']['shape']='diagonal_panel'; $front['lime_swoosh']['shape']='speed_swoosh'; $front['photo_frame']['x']=8; $front['photo_frame']['y']=30; $front['photo_frame']['w']=30; $front['photo_frame']['h']=48; $front['photo']['x']=9; $front['photo']['y']=31; $front['photo']['w']=28; $front['photo']['h']=46; $front['name']['x']=42; $front['name']['y']=35; $front['name']['w']=50; $front['name']['align']='left'; $front['position']['x']=42; $front['position']['y']=45; $front['position']['w']=50; $front['staff_id']['x']=42; $front['staff_id']['y']=53; $front['staff_id']['w']=30; $front['qr']['x']=76; $front['qr']['y']=67; $front['qr']['w']=16; $front['qr']['h']=16; return ['name'=>$name,'category'=>$category,'orientation'=>'landscape','front'=>$front,'back'=>$back]; }
    if ($name==='Modern Minimal') { foreach ($front as &$o){ if (($o['kind']??'')==='decor' && in_array($o['shape']??'', ['green_leaf_1','green_leaf_2'],true)) unset($o); } unset($o); $front['green_panel']['shape']='minimal_band'; $front['lime_swoosh']['opacity']=.25; return ['name'=>$name,'category'=>$category,'orientation'=>'portrait','front'=>$front,'back'=>$back]; }
    return ['name'=>$name,'category'=>$category,'orientation'=>$orientation,'front'=>$front,'back'=>$back];
}
function builtin_designs(): array {
    static $out=null; if($out!==null)return $out;
    $out=[];
    $out['classic']=generic_variant('Corporate Classic','Corporate','portrait','#155d3b','#76b82a');
    $out['executive']=generic_variant('Corporate Executive','Corporate','landscape','#155d3b','#76b82a');
    $out['logistics']=generic_variant('Logistics Bold','Logistics','landscape','#155d3b','#76b82a');
    $out['security']=generic_variant('Security Professional','Security','portrait','#155d3b','#76b82a');
    $out['school']=generic_variant('School Modern','School','portrait','#155d3b','#76b82a');
    $out['auto']=generic_variant('Automobile Pro','Automobile','landscape','#155d3b','#76b82a');
    $out['agro']=generic_variant('Agriculture / Agro','Agriculture','portrait','#166534','#84cc16');
    $out['farm']=generic_variant('Farm Professional','Agriculture','portrait','#166534','#84cc16');
    $out['minimal']=generic_variant('Modern Minimal','Modern','portrait','#155d3b','#76b82a');
    $out['split']=generic_variant('Modern Split','Modern','landscape','#155d3b','#76b82a');
    return $out;
}
function seed_builtin_templates(PDO $pdo): void {
    $check=$pdo->prepare("SELECT id FROM id_card_templates WHERE is_builtin=1 AND design_key=? LIMIT 1");
    $ins=$pdo->prepare("INSERT INTO id_card_templates (company_id,design_key,name,category,orientation,is_builtin,is_active,front_layout,back_layout) VALUES (NULL,?,?,?,?,1,1,?,?)");
    foreach(builtin_designs() as $key=>$d){
        $check->execute([$key]);
        $id=$check->fetchColumn();
        if($id){
            // Built-ins are canonical designs. Refresh them so installations upgrading
            // from v4.x receive the real structured artwork instead of legacy layouts.
            $pdo->prepare('UPDATE id_card_templates SET name=?,category=?,orientation=?,front_image=NULL,back_image=NULL,front_layout=?,back_layout=?,is_active=1 WHERE id=?')
                ->execute([$d['name'],$d['category'],$d['orientation'],json_encode($d['front']),json_encode($d['back']),$id]);
        } else {
            $ins->execute([$key,$d['name'],$d['category'],$d['orientation'],json_encode($d['front']),json_encode($d['back'])]);
        }
    }
}
function get_template(PDO $pdo,int $id):?array{$s=$pdo->prepare("SELECT * FROM id_card_templates WHERE id=? AND is_active=1 LIMIT 1");$s->execute([$id]);$r=$s->fetch();return $r?:null;}
function template_layout(array $template):array{$front=parse_layout($template['front_layout']??null);$back=parse_layout($template['back_layout']??null);if((!$front||!$back)&&!empty($template['design_key'])){$d=builtin_designs()[$template['design_key']]??null;if($d){if(!$front)$front=$d['front'];if(!$back)$back=$d['back'];}}return ['front'=>$front,'back'=>$back];}

function palette_color(string $key,array $settings): string { $palette=['primary'=>$settings['primary']??'#155d3b','secondary'=>$settings['secondary']??'#76b82a','text'=>$settings['text']??'#172033','muted'=>$settings['muted']??'#667085','white'=>'#ffffff']; return $palette[$key]??(preg_match('/^#[0-9a-fA-F]{3,8}$/',$key)?$key:$palette['text']); }
function render_card_face(string $side,string $orientation,string $designKey,array $layout,array $values,array $settings,?string $bgImage=null):string {
    $isBack=$side==='back'; $classes='card-stage '.e($orientation).' design-'.e($designKey?:'custom').' '.($isBack?'back':'front');
    $style='--primary:'.e(palette_color('primary',$settings)).';--secondary:'.e(palette_color('secondary',$settings)).';--text:'.e(palette_color('text',$settings)).';--muted:'.e(palette_color('muted',$settings)).';';
    $html='<div class="'.$classes.'" style="'.$style.'">';
    if($bgImage){ /* legacy artwork ignored intentionally: uploaded-design templates are no longer supported */ }
    $items=[]; foreach($layout as $id=>$p){if(!is_array($p))continue;$p['_id']=$id;$items[]=$p;} usort($items,fn($a,$b)=>(int)($a['z']??2)<=>(int)($b['z']??2));
    foreach($items as $p){
        $type=(string)($p['field']??$p['shape']??$p['kind']??'');
        if($isBack&&in_array($type,['qr','qr_label'],true))continue;
        if(!$isBack&&in_array($type,['signature','signature_label','important','important_title','contact','contact_title','dates'],true))continue;
        if(($settings['show_tagline']??true)===false&&$type==='tagline')continue;
        if(($settings['show_bottom_text']??true)===false&&in_array($type,['bottom_text','back_bottom'],true))continue;
        $html.=field_markup($type,$p,$values,$settings);
    }
    return $html.'</div>';
}
function field_markup(string $type,array $p,array $values,array $settings):string {
    $x=(float)($p['x']??0);$y=(float)($p['y']??0);$w=(float)($p['w']??10);$h=(float)($p['h']??5);$kind=(string)($p['kind']??'field');$shape=(string)($p['shape']??'');
    $z=(int)($p['z']??3);$rot=(float)($p['rotation']??0);$opacity=max(0,min(1,(float)($p['opacity']??1)));$color=palette_color((string)($p['color']??'text'),$settings);
    $style="left:{$x}%;top:{$y}%;width:{$w}%;height:{$h}%;z-index:{$z};opacity:{$opacity};transform:rotate({$rot}deg);";
    if($kind==='decor'){
        $style.='--el-color:'.e($color).';';
        return '<div class="design-object decor-object shape-'.e($shape).'" data-object="'.e((string)($p['_id']??$type)).'" style="'.$style.'"></div>';
    }
    $shapeClass=$type==='photo'?($values['photo_shape_override']??($p['shape']??($settings['photo_shape']??'rounded'))):$shape;
    $cls='design-object field-el field-'.e($type).($shapeClass?' '.e($shapeClass):'');
    if(!in_array($type,['photo','logo','signature','qr'],true)){
        $fs=(float)($p['fontSize']??8);$weight=e((string)($p['weight']??'500'));$align=e((string)($p['align']??'left'));$justify=$align==='center'?'center':($align==='right'?'flex-end':'flex-start');
        $style.="font-size:{$fs}px;font-weight:{$weight};text-align:{$align};justify-content:{$justify};color:".e($color).';';
        if(in_array($type,['title','position','qr_label','signature_label','back_bottom','bottom_text','tagline'],true))$style.='text-transform:uppercase;letter-spacing:.55px;';
        if(in_array($type,['important','contact'],true))$style.='white-space:pre-line;line-height:1.4;display:block;';
        if($type==='name'&&$align==='left')$style.='padding-left:1.5mm;';
    }
    switch($type){
      case 'photo':
        $url=$values['photo_url']??'';$zoom=max(.8,min(3,(float)($values['photo_zoom']??1)));$cx=max(-50,min(50,(float)($values['photo_cx']??0)));$cy=max(-50,min(50,(float)($values['photo_cy']??0)));
        $content=$url?'<img src="'.e($url).'" alt="" style="transform:translate('.$cx.'%,'.$cy.'%) scale('.$zoom.');">':'<span class="placeholder">PHOTO</span>';break;
      case 'logo': $content=!empty($values['logo_url'])?'<img src="'.e($values['logo_url']).'" alt="">':'<span class="placeholder">LOGO</span>';break;
      case 'signature': if(empty($values['signature_url']))return ''; $content='<img src="'.e($values['signature_url']).'" alt="">';break;
      case 'qr': $content='<div class="qr-box" data-qr="'.e((string)($values['verification_url']??'')).'"></div>';break;
      default: $content=nl2br(e((string)($values[$type]??'')));
    }
    return '<div class="'.$cls.'" data-field="'.e($type).'" data-object="'.e((string)($p['_id']??$type)).'" style="'.$style.'">'.$content.'</div>';
}
function card_engine_css():string{return <<<CSS
.card-stage{position:relative;background:#fff;overflow:hidden;font-family:Arial,Helvetica,sans-serif;color:var(--text);border-radius:1.7%;border:.3mm solid rgba(16,24,40,.12);box-sizing:border-box}
.card-stage.portrait{aspect-ratio:53.98/85.6}.card-stage.landscape{aspect-ratio:85.6/53.98}
.design-object{position:absolute;box-sizing:border-box;overflow:hidden}.field-el{line-height:1.12;white-space:normal;word-break:normal;overflow:hidden;display:flex;align-items:center}.field-important,.field-contact{display:block!important;white-space:pre-line}.field-dates{display:block!important;text-align:center}
.field-el img{width:100%;height:100%;display:block;object-fit:contain}.field-photo{background:#eef0f3;border:.45mm solid #fff;display:flex;align-items:center;justify-content:center;box-shadow:0 1mm 2.2mm rgba(16,24,40,.18);overflow:hidden}.field-photo img{object-fit:contain;transform-origin:center}.field-photo.circle{border-radius:50%}.field-photo.rounded{border-radius:2mm}.field-logo img{object-fit:contain}.field-qr{background:#fff;padding:.8mm;border-radius:1mm}.qr-box{width:100%;height:100%}.field-qr-label{white-space:nowrap}.placeholder{font-size:8px;color:#98a2b3;font-weight:800}.field-title{letter-spacing:1px}
.decor-object{background:var(--el-color);pointer-events:none}.shape-background{background:#fff}.shape-header_cutout{background:#fff!important;border-radius:0 0 48% 48%/0 0 58% 58%}.shape-organic_panel{border-radius:0 0 70% 34%/0 0 85% 28%;transform-origin:center}.shape-swoosh{border:5px solid var(--el-color);border-left-color:transparent;border-bottom-color:transparent;border-radius:50%;background:transparent!important}.shape-speed_swoosh{border:3px solid var(--el-color);border-left-color:transparent;border-bottom-color:transparent;border-radius:50%;background:transparent!important}.shape-leaf{border-radius:100% 0 100% 0/100% 0 100% 0;transform-origin:center}.shape-leaf_cluster{border-radius:50%;background:radial-gradient(ellipse at 30% 70%,var(--el-color) 0 20%,transparent 21%),radial-gradient(ellipse at 55% 45%,var(--el-color) 0 24%,transparent 25%),radial-gradient(ellipse at 75% 20%,var(--el-color) 0 18%,transparent 19%);}.shape-photo_frame{background:transparent;border:1.2px solid var(--el-color);border-radius:2.2mm;box-shadow:0 1mm 2mm rgba(16,24,40,.1)}.shape-circle_frame{background:transparent;border:1.2px solid var(--el-color);border-radius:50%}.shape-pill{border-radius:999px}.shape-line{height:2px!important;min-height:2px;border-radius:4px}.shape-bottom_band{border-radius:0;background:var(--el-color)}.shape-diagonal_panel{clip-path:polygon(0 0,100% 0,86% 100%,0 82%);border-radius:0}.shape-security_band{clip-path:polygon(0 0,100% 0,92% 100%,8% 100%);border-radius:0}.shape-school_band{clip-path:ellipse(75% 100% at 50% 0);border-radius:0}.shape-minimal_band{height:2.2%!important;background:var(--el-color);border-radius:0}.shape-organic_panel:after{content:"";position:absolute;right:-4%;top:5%;width:45%;height:70%;border-radius:50%;background:rgba(255,255,255,.2)}
.design-agro .shape-organic_panel,.design-farm .shape-organic_panel{background:linear-gradient(125deg,var(--primary),var(--secondary))}.design-agro .shape-swoosh,.design-farm .shape-swoosh{border-width:6px}.design-classic .shape-organic_panel{background:linear-gradient(125deg,var(--primary),var(--secondary))}.design-executive .shape-organic_panel,.design-logistics .shape-diagonal_panel,.design-auto .shape-diagonal_panel,.design-split .shape-diagonal_panel{background:linear-gradient(125deg,var(--primary),var(--secondary))}.design-security .shape-security_band,.design-school .shape-school_band{background:linear-gradient(110deg,var(--primary),var(--secondary))}.design-minimal .shape-organic_panel{background:var(--primary)}
CSS;}
