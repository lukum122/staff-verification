<?php
require_once __DIR__.'/../config/config.php';
require_once __DIR__.'/../config/database.php';
require_once __DIR__.'/../includes/functions.php';

$token = strtoupper(trim($_GET['token'] ?? ''));
$staff = null;
$result = 'not_found';

if (preg_match('/^[A-Z0-9_-]{12,32}$/', $token)) {
    $stmt = $pdo->prepare(
        "SELECT s.*, c.name company_name, c.logo company_logo, c.status company_status
         FROM staff s INNER JOIN companies c ON c.id=s.company_id
         WHERE s.verification_token=? LIMIT 1"
    );
    $stmt->execute([$token]);
    $staff = $stmt->fetch();

    if ($staff) {
        $result = (staff_is_currently_active($staff) && $staff['company_status']==='active') ? 'verified' : 'inactive';
        log_verification($pdo, (int)$staff['id'], (int)$staff['company_id'], $token, $result);
    } else {
        log_verification($pdo, null, null, $token, 'not_found');
    }
} else {
    log_verification($pdo, null, null, $token ?: null, 'not_found');
}

$valid = $result === 'verified';
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title><?= $valid ? 'Verified Staff' : ($result==='inactive' ? 'Inactive Staff' : 'Verification Failed') ?> · SVP</title>
<link rel="stylesheet" href="<?=e(base_url('assets/css/style.css'))?>">
</head>
<body>
<main class="verify-page">
<section class="verify-card">
  <div class="brand centered"><span>SVP</span><small>Staff Verification Portal</small></div>

  <?php if ($valid): ?>
    <div class="verify-icon success-icon">✓</div>
    <h1>Verified Staff</h1>
    <p class="muted">This staff credential is currently valid according to our records.</p>
  <?php elseif ($result==='inactive'): ?>
    <div class="verify-icon danger-icon">!</div>
    <h1>Inactive Staff</h1>
    <p class="muted">This staff credential is no longer active according to our records.</p>
  <?php else: ?>
    <div class="verify-icon danger-icon">!</div>
    <h1>Verification Failed</h1>
    <p class="muted">This verification code could not be found in our records. Check the QR code or Staff ID and try again.</p>
  <?php endif; ?>

  <?php if ($staff): ?>
    <div class="public-profile">
      <?php if($staff['photo']): ?><img class="profile-photo" src="<?=e(base_url($staff['photo']))?>" alt="Staff photo"><?php else: ?><div class="profile-placeholder">SVP</div><?php endif; ?>
      <h2><?=e(trim($staff['first_name'].' '.($staff['middle_name'] ?? '').' '.$staff['last_name']))?></h2>
      <div class="muted"><?=e($staff['staff_id'])?></div>
      <div class="details public-details">
        <div><strong>Company</strong><span><?=e($staff['company_name'])?></span></div>
        <div><strong>Position</strong><span><?=e($staff['position'])?></span></div>
        <?php if($staff['department']): ?><div><strong>Department</strong><span><?=e($staff['department'])?></span></div><?php endif; ?>
        <?php if($staff['date_employed']): ?><div><strong>Date Employed</strong><span><?=e($staff['date_employed'])?></span></div><?php endif; ?>
        <div><strong>Status</strong><span><?=status_badge($valid ? 'active' : 'inactive')?></span></div>
        <div><strong>Verification ID</strong><span><?=e($staff['verification_token'])?></span></div>
      </div>
    </div>
  <?php endif; ?>

  <a class="btn full" href="<?=e(base_url())?>">Verify Another Staff</a>
  <p class="small muted">Verified by Staff Verification Portal (SVP)</p>
</section>
</main>
</body>
</html>
