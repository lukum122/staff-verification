<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';

$existing=(int)$pdo->query("SELECT COUNT(*) FROM admins")->fetchColumn();
$message='';

if($_SERVER['REQUEST_METHOD']==='POST' && $existing===0){
 $name=trim($_POST['name']??'');$email=trim($_POST['email']??'');$password=$_POST['password']??'';
 if(!$name||!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($password)<10){
   $message='Use a name, valid email and password of at least 10 characters.';
 }else{
   try{
     $stmt=$pdo->prepare("INSERT INTO admins(name,email,password_hash) VALUES(?,?,?)");
     $stmt->execute([$name,$email,password_hash($password,PASSWORD_DEFAULT)]);
     $message='Administrator created successfully. Delete setup_admin.php from the server before normal use, then sign in.';
     $existing=1;
   }catch(Throwable $e){$message='Could not create administrator. The email may already exist.';}
 }
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SVP Setup</title><link rel="stylesheet" href="<?=e(base_url('assets/css/style.css'))?>"></head><body><main class="container"><div class="form-card narrow"><div class="svp-mark">SVP</div><h2>First-Time Setup</h2>
<?php if($existing>0): ?><div class="alert">An administrator already exists. Delete setup_admin.php and use the login page.</div><a class="btn full" href="<?=e(base_url('login.php'))?>">Go to Login</a>
<?php else: ?>
<?php if($message):?><div class="alert"><?=e($message)?></div><?php endif;?>
<form method="post"><div class="field"><label>Name</label><input name="name" required></div><div class="field"><label>Email</label><input type="email" name="email" required></div><div class="field"><label>Password</label><input type="password" name="password" minlength="10" required></div><button class="btn full">Create Administrator</button></form>
<?php endif; ?></div></main></body></html>
